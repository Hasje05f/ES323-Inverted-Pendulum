% create_controller_params.m
clc;
dir = "C:\Users\bouba\OneDrive\Bureaublad\ES323 v1.1";
cd(dir);
% ===== DEFINE YOUR CONTROLLER PARAMETERS HERE =====

% Choose controller type: 'open_loop', 'classical', 'state_feedback', 'extended_sf'
controller_type = 'open_loop';

% Initialize params struct
params = struct();
params.controller_type = controller_type;
params.add_noise = false;

% Define parameters based on controller type
switch controller_type
    case 'open_loop'        
        params.trajectory = zeros(400,1); % Trajectory for open loop

    case 'classical' 
        params.w = 0;  % setpoint
        
    case 'state_feedback'
        params.w = 0.25/final_value(1);              % setpoint
        
    case 'extended_sf'
        params.w = 0.25;               % setpoint
end

% Save to JSON file
output_file = 'controller_params.json';
fid = fopen(output_file, 'w');
fwrite(fid, jsonencode(params));
fclose(fid);

fprintf('✓ Parameters saved to: %s\n', output_file);
fprintf('  Controller type: %s\n', controller_type);
disp('  Now run: python PROJECT.py');
