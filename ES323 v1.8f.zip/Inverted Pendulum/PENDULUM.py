import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.animation as animation

# --- SYSTEM (Pendulum - Cart-Pole) ---

class Pendulum:
    def __init__(self, T, add_noise=True):
        self.T = T
        self.t = 0
        self.state = np.array([-0.25, 0.0, 0.05, 0.0])  # [x, v, phi, omega]
        self.u = 0.0
        self.disturbance = 0.0
        self.add_noise = add_noise
        self.params = {
            'L': 0.3,           # pendulum length [m]
            'M': 0.5,           # mass of cart [kg]
            'm': 0.2,           # mass of pendulum [kg]
            'friction': 0.1,    # friction coefficient for cart
            'max_F': 10.0,      # max allowed force [N]
            'rail_length': 1.0, # length of the rail
            'cart_length': 0.1, # half length of cart
        }
        self.pendulum_saturation = np.pi / 2.1

    def step(self, u):
        self.u = self._constrain_input(u)
        self.state += self._rk4(self.t, self.state, self.u)
        self.t += self.T
        self._constrain_state()

    def _rk4(self, t, x, u):
        h = self.T
        f = self.deriv
        k1 = f(t, x, u)
        k2 = f(t + h/2, x + k1*h/2, u)
        k3 = f(t + h/2, x + k2*h/2, u)
        k4 = f(t + h, x + k3*h, u)
        return (h/6)*(k1 + 2*k2 + 2*k3 + k4)

    def deriv(self, t, x, u):
        """Computes first derivatives for cart-pole system"""
        L = self.params['L']
        m = self.params['m']
        M = self.params['M']
        b = self.params['friction']
        
        # Moment of inertia about center of mass of rod
        I = 1/12 * m * L**2
        g = 9.81
        
        x_pos, v, phi, omega = x[0], x[1], x[2], x[3]
        rho = L / 2  # distance to center of mass
        
        x_dot = np.zeros(4)
        x_dot[0] = v
        
        # Cart acceleration
        num_cart = -g*m**2*rho**2*np.sin(phi)*np.cos(phi) + m*(m*rho**2 + I)*rho*omega**2*np.sin(phi) + b*(m*rho**2 + I)*v - (I + m*rho**2)*u
        den_cart = m**2*rho**2*np.cos(phi)**2 - (M + m)*(m*rho**2 + I)
        x_dot[1] = num_cart / den_cart
        
        x_dot[2] = omega
        
        # Pendulum angular acceleration
        num_pend = g*m*(M + m)*rho*np.sin(phi) - m*b*rho*np.cos(phi)*v - m**2*rho**2*omega**2*np.sin(phi)*np.cos(phi) + m*rho*np.cos(phi)*u
        den_pend = (M + m)*(I + m*rho**2) - m**2*rho**2*np.cos(phi)**2
        x_dot[3] = num_pend / den_pend
        
        # Apply pendulum saturation constraints
        if (self.state[2] == self.pendulum_saturation and x_dot[3] > 0) or \
           (self.state[2] == -self.pendulum_saturation and x_dot[3] < 0):
            x_dot[1] = (u - b*x[1]) / (M + m)
            x_dot[3] = 0.0
        
        return x_dot

    def get_measurement(self):
        """Returns measurement: [time, cart position, pendulum angle]"""
        measurement = [self.t, self.state[0], self.state[2]]
        if self.add_noise:
            measurement[1] += np.random.normal(scale=0.01)
            measurement[2] += np.random.normal(scale=0.005)
        # Wrap angle to [-pi, pi]
        if abs(measurement[2]) > np.pi:
            measurement[2] = measurement[2] - np.sign(measurement[2]) * 2 * np.pi
        return measurement

    def _constrain_input(self, u):
        max_F = self.params['max_F']
        if u < -max_F:
            return -max_F
        elif u > max_F:
            return max_F
        return u

    def _constrain_state(self):
        x, v, phi, omega = self.state[0], self.state[1], self.state[2], self.state[3]
        length = self.params['rail_length']
        cart_len = self.params['cart_length']
        
        # Cart position constraint
        if x < -length + cart_len/2:
            x = -length + cart_len/2
            v = 0.0
        elif x > length - cart_len:
            x = length - cart_len
            v = 0.0
        
        # Pendulum angle constraint
        if phi > self.pendulum_saturation:
            phi = self.pendulum_saturation
            omega = 0.0
        elif phi < -self.pendulum_saturation:
            phi = -self.pendulum_saturation
            omega = 0.0
        
        self.state[0] = x
        self.state[1] = v
        self.state[2] = phi
        self.state[3] = omega


# --- CONTROLLER EXAMPLES ---

class OpenLoopController:
    def __init__(self, U):
        self.U = U
        self.idx = 0

    def __call__(self, y=None):
        u = self.U[self.idx] if self.idx < len(self.U) else 0.0
        self.idx += 1
        return u

#############################################################################################################
##########################  ClassicalController zonder x controller #########################################
#############################################################################################################


# class ClassicalController:
#     def __init__(self, w=0.0):
#         self.w = w

#         self.e_prev1 = 0.0
#         self.e_prev2 = 0.0
#         self.u_prev1 = 0.0
#         self.u_prev2 = 0.0

#     def __call__(self, y):
#         theta = y[1]
#         e = self.w - theta

#         u = (  0.3   * self.u_prev1
#              + 0.7   * self.u_prev2
#              + 90.7  * e
#              - 130.3 * self.e_prev1
#              + 46.19 * self.e_prev2 )

#         self.e_prev2 = self.e_prev1;  self.e_prev1 = e
#         self.u_prev2 = self.u_prev1;  self.u_prev1 = u

#         return u

#############################################################################################################
############################  ClassicalController met x controller ##########################################
#############################################################################################################

class ClassicalController:
    def __init__(self, w_x=0.0):
        self.w_x = w_x      # gewenste kartpositie

        # Geheugen binnenste lus (theta)
        self.e_th_prev1 = 0.0
        self.e_th_prev2 = 0.0
        self.u_prev1    = 0.0
        self.u_prev2    = 0.0

    def __call__(self, y):
        x     = y[0]
        theta = y[1]

        # Buitenste lus: P op positie -> genereert theta-setpoint
        Kp_x = -0.5       # <-- aan te passen
        w_theta = Kp_x * (self.w_x - x)

        # Begrens w_theta zodat de pendulum niet te ver kantelt
        w_theta = max(min(w_theta, 0.15), -0.15)   # ± ~9°

        # Binnenste lus: bestaande C_theta(z)
        e = w_theta - theta

        u = (  0.3   * self.u_prev1
             + 0.7   * self.u_prev2
             + 90.7  * e
             - 130.3 * self.e_th_prev1
             + 46.19 * self.e_th_prev2 )

        self.e_th_prev2 = self.e_th_prev1;  self.e_th_prev1 = e
        self.u_prev2    = self.u_prev1;     self.u_prev1    = u

        marge = 0.1
        u = max(min(u, (1-marge)*10.0), -(1-marge)*10.0) # Neem een kleine marge van de maximale fysieke spanning van 10N voor de motor.

        return u


class StateFeedbackController:
    def __init__(self, observer, K, Nbar, w=0.0):
        self.observer = observer
        self.K    = np.array(K)
        self.Nbar = Nbar
        self.w    = w

    def __call__(self, y):
        x_hat = self.observer(y)

        # x_hat = system.state.copy()
        # x_hat[1] += np.random.normal(scale=0.01)
        # x_hat[2] += np.random.normal(scale=0.005)
        u = self.Nbar * self.w - self.K @ x_hat
        return float(np.clip(u, -9.0, 9.0))

class ExtendedStateFeedbackController:
    def __init__(self, observer, K, Ki, w=0.0):
        self.observer = observer
        self.K   = np.array(K)
        self.Ki  = Ki
        self.w   = w
        self.SE  = 0.0          # integratortoestand S_E

    def __call__(self, y):
        x_hat = self.observer(y)
        # x_hat = system.state.copy()
        
        # Integrator update: S_E[k+1] = S_E[k] + (x[k] - w)
        x_hat_pos = x_hat[0]    # geschatte kartpositie
        self.SE += (x_hat_pos - self.w)

        # Uitgebreide toestandsterugkoppeling: u = -K*x_hat - Ki*S_E
        u = -(self.K @ x_hat + self.Ki * self.SE)

        return float(np.clip(u, -9.0, 9.0))

#############################################################################################################
##########################################  T B D ###########################################################
#############################################################################################################

# --- OBSERVER CLASS ---
class Observer:
    def __init__(self, T, A, B, C, L):
        self.T = T
        self.A = np.array(A)
        self.B = np.array(B)
        self.C = np.array(C)
        self.L = np.array(L)
        self.x_hat = np.zeros(4)   # begintoestand observer
        self.u_prev = 0.0          # vorige stuurkracht

    def __call__(self, y):
        # Observer update: x_hat[k+1] = A*x_hat[k] + B*u[k] + L*(y[k] - C*x_hat[k])
        y = np.array(y)
        y_hat = self.C @ self.x_hat
        self.x_hat = (self.A @ self.x_hat
                      + self.B * self.u_prev
                      + self.L @ (y - y_hat))
        return self.x_hat.copy()
        
    def set_input(self, u):
        self.u_prev = u
       
#############################################################################################################
#############################################################################################################
#############################################################################################################


# --- SIMULATION FUNCTION ---

def simulate(system, controller, timesteps):
    xs, us, ys = [], [], []
    for _ in range(timesteps):
        y_full = system.get_measurement()
        y = np.array([y_full[1], y_full[2]])
        u = controller(y)
        # Geef de gebruikte stuurkracht door aan de observer
        if hasattr(controller, 'observer'):
            controller.observer.set_input(u)
        xs.append(system.state.copy())
        ys.append(y)
        us.append(u)
        system.step(u)
    return xs, us, ys


# --- ANIMATION ---

def animate_simulation(xs, us, save_path='pendulum_animation.gif', L=0.3, cart_length=0.1, interval=10):
    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    ax.grid()
    
    rail_length = 1.0
    ax.set_xlim([-1.1*rail_length, 1.1*rail_length])
    ax.set_ylim([-0.2, 0.8])
    
    # Create cart
    cart = ax.add_patch(patches.Rectangle(
        (0.0 - cart_length, 0.0),
        width=2*cart_length,
        height=cart_length,
        fc='blue', ec='black', lw=2
    ))
    
    # Create pendulum
    pendulum, = ax.plot([], [], 'r-', lw=3, marker='o', markersize=8)
    
    text = ax.text(-0.9*rail_length, 0.7, '')
    
    def init():
        cart.set_xy((0 - cart_length, 0.0))
        pendulum.set_data([], [])
        text.set_text('')
        return cart, pendulum, text

    def animate(i):
        x, v, phi, omega = xs[i][0], xs[i][1], xs[i][2], xs[i][3]
        F = us[i]
        
        # Cart position
        cart.set_x(x - cart_length)
        
        # Pendulum: from cart position to pendulum tip
        pend_start_x = x
        pend_start_y = cart_length * 0.9
        pend_end_x = x - L * np.sin(phi)
        pend_end_y = cart_length * 0.9 + L * np.cos(phi)
        
        pendulum.set_data([pend_start_x, pend_end_x], [pend_start_y, pend_end_y])
        
        text.set_text(f'x={x:+.2f}, v={v:+.2f}, φ={phi:.2f}, F={F:+.2f}')
        
        return cart, pendulum, text

    anim = animation.FuncAnimation(
        fig, animate, init_func=init, frames=len(xs),
        interval=interval, blit=True
    )

    # if save_path is not None:
    #     print(f"Opslaan als GIF: {save_path} ...")
    #     anim.save(save_path, writer='pillow', fps=30)
    #     print("✓ GIF opgeslagen.")  

    plt.show()


# --- MAIN SCRIPT ---

if __name__ == '__main__':
    import json
    import sys

    # Load parameters from JSON
    config_file = 'controller_params.json'
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"Error: {config_file} not found!")
        print("Run MATLAB script 'create_controller_params.m' first")
        sys.exit(1)

    obs_config_file = 'observer_params.json'
    try:
        with open(obs_config_file, 'r') as f:
            obs_config = json.load(f)
    except FileNotFoundError:
        print(f"Error: {obs_config_file} not found!")
        sys.exit(1)

    # Extract config
    controller_type = config['controller_type']
    params = config
    timesteps = 400
    add_noise = config.get('add_noise', True)

    print(f"\n{'='*60}")
    print(f"Cart-Pole (Inverted Pendulum) Control System")
    print(f"{'='*60}")
    print(f"Controller Type: {controller_type}")
    print(f"Timesteps: {timesteps}")
    print(f"Noise: {add_noise}")
    print(f"{'='*60}\n")

    # Initialize system
    system = Pendulum(T=0.05, add_noise=add_noise)
    controller = None

#############################################################################################################
##########################################  T B D ###########################################################
#############################################################################################################

    # Setup controller based on type
    if controller_type == 'open_loop':
        U = np.array(params.get('trajectory', [0.0]*timesteps))
        controller = OpenLoopController(U)
        print("✓ Open-loop controller initialized")
        print(f" Trajectory length: {len(U)}")

    elif controller_type == 'classical':
        controller = ClassicalController(
            w_x=params.get('w', 0.0)
            #w=params.get('w', 0.0)
        )
        print("✓ Classical controller initialized")
        print(f"  w (setpoint)={params.get('w', 0.0)}")
        
    elif controller_type == 'state_feedback':
        observer = Observer(
            T = 0.05,
            A = obs_config['A'],
            B = obs_config['B'],
            C = obs_config['C'],
            L = obs_config['L']
        )
        controller = StateFeedbackController(
            observer,
            K    = params.get('K'),
            Nbar = params.get('Nbar'),
            w    = params.get('w', 0.0)
        )     
        print("✓ State-feedback controller initialized")
        print(f"  w (setpoint) = {params.get('w', 0.0)}")
        
    elif controller_type == 'extended_sf':
        observer = Observer(
            T = 0.05,
            A = obs_config['A'],
            B = obs_config['B'],
            C = obs_config['C'],
            L = obs_config['L']
        )
        controller = ExtendedStateFeedbackController(
            observer,
            K  = params.get('K'),
            Ki = params.get('Ki'),
            w  = params.get('w', 0.0)
        )
        print("✓ Extended state-feedback controller initialized")
        print(f"  w (setpoint) = {params.get('w', 0.0)}")
    else:
        print(f"ERROR: Unknown controller type: {controller_type}")
        sys.exit(1)

    print("\nRunning simulation...\n")

#############################################################################################################
#############################################################################################################
#############################################################################################################

    # RUN SIMULATION
    xs, us, ys = simulate(system, controller, timesteps)

    # Extract states
    positions = [x[0] for x in xs]
    velocities = [x[1] for x in xs]
    angles = [x[2] for x in xs]
    angle_vels = [x[3] for x in xs]

    # Calculate simulation time
    sim_time = timesteps * system.T

    # PLOT AFTER SIMULATION
    ts = np.linspace(0, sim_time, timesteps)

    plt.figure(figsize=(14, 10))

    plt.subplot(3, 1, 1)
    plt.plot(ts, positions, label='Cart Position (x)', linewidth=2)
    plt.plot(ts, velocities, label='Cart Velocity (v)', linewidth=2, alpha=0.7)
    plt.ylabel('Position / Velocity (m, m/s)')
    plt.legend(loc='best')
    plt.grid(True, alpha=0.3)
    plt.title(f'{controller_type.upper()} Controller Response', fontweight='bold')

    plt.subplot(3, 1, 2)
    plt.plot(ts, angles, label='Pendulum Angle (φ)', linewidth=2, color='orange')
    plt.plot(ts, angle_vels, label='Pendulum Ang. Vel. (ω)', linewidth=2, alpha=0.7, color='red')
    plt.ylabel('Angle / Ang. Velocity (rad, rad/s)')
    plt.legend(loc='best')
    plt.grid(True, alpha=0.3)

    plt.subplot(3, 1, 3)
    plt.plot(ts, us, linewidth=2, color='green')
    plt.ylabel('Control Force (F) [N]')
    plt.xlabel('Time (s)')
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    # Animate simulation
    animate_simulation(xs, us)

    # After simulation, convert lists to arrays for saving
    xs_array = np.array(xs)
    us_array = np.array(us)
    ys_array = np.array(ys)

    # Save CSV files
    np.savetxt('pendulum_states.csv', xs_array, delimiter=',', header='x,v,phi,omega', comments='')
    np.savetxt('pendulum_inputs.csv', us_array, delimiter=',', header='force', comments='')
    np.savetxt('pendulum_measurements.csv', ys_array, delimiter=',', header='x,phi', comments='')

    print(f"\n{'='*60}")
    print(f"✓ Simulation complete: {timesteps} steps")
    print(f" Max position (touched border? x=0.9000): {max(positions):.4f} m")
    print(f" Max used force: {max(max(us),abs(min(us))):.4f} N")
    print(f" Final cart position: {positions[-1]:.4f} m")
    print(f" Final cart velocity: {velocities[-1]:.4f} m/s")
    print(f" Final angle: {angles[-1]:.4f} rad")
    print(f" Final control: {us[-1]:.4f} N")
    print(f"\n✓ CSV files saved:")
    print(f" - pendulum_states.csv (x, v, phi, omega)")
    print(f" - pendulum_inputs.csv (control force)")
    print(f" - pendulum_measurements.csv (measured x, phi)")
    print(f"{'='*60}\n")
