%% ObserverOpt.m — Automatische optimalisatie van observer-Polen via gewogen RMS
%
% WORKFLOW:
%   Stap 1 (Python): Draai simulatie met ideale observer (system.state kopiëren)
%                    zodat de controller goed werkt. Sla op als CSV.
%   Stap 2 (hier):   Laad CSV, optimaliseer de 4 observer-Polen door de gewogen
%                    RMS-fout op NIET-gemeten toestanden te minimaliseren.
%
% Vereiste workspace-variabelen (aanwezig na MATLAB_Code.m + StateFeedback.m):
%   sys_d, A_d, B_d, C_d, Ts
%
% Toestandsvector:  x = [x;  x_dot;  theta;  theta_dot]
% Metingen:         y = [x;  theta]
% Kostfunctie:      J = w1*RMS(e_xdot) + w2*RMS(e_thetadot)
%                       + w3*RMS(e_x)  + w4*RMS(e_theta)
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  OBSERVER POOL-OPTIMALISATIE — gewogen RMS minimalisatie\n');
fprintf('  Ts = %.3f s\n', Ts);
fprintf('============================================================\n\n');

%% ── 0. Systeemmatrices ──────────────────────────────────────────────────
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;

%% ── 1. Kalibratiedata laden ─────────────────────────────────────────────
csv_dir = fullfile(dir, 'Simulations Flament', ...
    'Calibratie Observer State Feedback - PCl[0.85 0.80 0.70 0.65] - Met noise');

fprintf('Laden van CSV vanuit:\n  %s\n\n', csv_dir);
try
    data_states  = readmatrix(fullfile(csv_dir, 'pendulum_states.csv'));
    data_inputs  = readmatrix(fullfile(csv_dir, 'pendulum_inputs.csv'));
    data_meas    = readmatrix(fullfile(csv_dir, 'pendulum_measurements.csv'));
catch
    warning('Map niet gevonden — huidige map gebruikt.');
    data_states  = readmatrix('pendulum_states.csv');
    data_inputs  = readmatrix('pendulum_inputs.csv');
    data_meas    = readmatrix('pendulum_measurements.csv');
end

N_csv     = size(data_states, 1);
t_csv     = (0:N_csv-1).' * Ts;
x_ref     = data_states(:,1);
v_ref     = data_states(:,2);
phi_ref   = data_states(:,3);
omega_ref = data_states(:,4);
y_csv     = data_meas';          % 2 x N
u_csv     = data_inputs(:,1);   % N x 1

fprintf('Data geladen: %d tijdstappen (%.1f s).\n\n', N_csv, t_csv(end));

%% ── 2. Gewichten kostfunctie ────────────────────────────────────────────
w_v  = 1;   % x_dot     (NIET gemeten — zwaar gewicht)
w_om = 1;   % theta_dot (NIET gemeten — zwaar gewicht)
w_x  = 1;   % x         (gemeten    — laag gewicht, sanity check)
w_ph = 1;   % theta     (gemeten    — laag gewicht, sanity check)

cost_fun = @(p) observer_cost(p, A_d, B_d, C_d, y_csv, u_csv, ...
                               v_ref, omega_ref, x_ref, phi_ref, ...
                               w_v, w_om, w_x, w_ph);

%% ── 3. Optimalisatie met fmincon ────────────────────────────────────────
%
% NOOT: als een pool de bovengrens ub raakt (bv. p=0.99), wil de optimizer
% eigenlijk nog trager gaan. Dit is normaal voor de langzame positiedynamica
% van x. Verhoog ub voorzichtig naar 0.995 en heroptimaliseer indien gewenst,
% maar verifieer daarna de ruisversterking in gesloten lus (Python simulatie).
%
lb = 0.01 * ones(1,4);
ub = 0.99 * ones(1,4);


start_candidates = [
    0.80 0.70 0.60 0.50;
    0.60 0.50 0.40 0.30;
    0.40 0.35 0.25 0.15;
    0.55 0.45 0.30 0.20;
    0.70 0.55 0.40 0.25;
    0.30 0.25 0.20 0.15;
    0.50 0.40 0.30 0.10;
    0.65 0.60 0.25 0.20;
    0.75 0.70 0.30 0.25;
    0.90 0.92 0.15 0.10;
];

opts_fmincon = optimoptions('fmincon', ...
    'Display',       'off', ...
    'MaxIterations', 500,   ...
    'TolFun',        1e-8,  ...
    'TolX',          1e-8);

fprintf('Optimalisatie gestart (%d startpunten)...\n\n', size(start_candidates,1));

best_J = inf;
best_p = [];

for s = 1:size(start_candidates, 1)
    p0 = start_candidates(s,:);
    try
        [p_s, J_s] = fmincon(cost_fun, p0, [], [], [], [], lb, ub, ...
                              @pole_separation, opts_fmincon);
        if J_s < best_J
            best_J = J_s;
            best_p = p_s;
        end
        fprintf('  Start %d: J = %.6f   Polen = [%.4f %.4f %.4f %.4f]\n', ...
            s, J_s, p_s(1), p_s(2), p_s(3), p_s(4));
    catch ME
        fprintf('  Start %d: mislukt (%s)\n', s, ME.message);
    end
end
fprintf('\n');

%% ── 4. Resultaat ────────────────────────────────────────────────────────
P_obs_opt = sort(best_p, 'descend');
L_opt     = place(A_d', C_d', P_obs_opt)';
A_obs_opt = A_d - L_opt * C_d;
p_check   = eig(A_obs_opt);

fprintf('============================================================\n');
fprintf('  OPTIMALE OBSERVER-POLEN\n');
fprintf('============================================================\n');
fprintf('  P_obs_opt = [%.4f, %.4f, %.4f, %.4f]\n', P_obs_opt);
fprintf('  Kostfunctie J_min = %.6f\n\n', best_J);

if any(P_obs_opt >= ub(1) - 0.005)
    fprintf('  [!] Een pool raakt de bovengrens (ub=%.3f).\n', ub(1));
    fprintf('      Dit is de trage positiepool. Overweeg ub=0.995 en\n');
    fprintf('      heroptimaliseer, maar test ruisgedrag achteraf.\n\n');
end

fprintf('Verificatie eigenwaarden (A_d - L*C_d):\n');
for i = 1:4
    stabstr = '';
    if abs(p_check(i)) >= 1, stabstr = '  <-- INSTABIEL!'; end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_check(i)), imag(p_check(i)), abs(p_check(i)), stabstr);
end
fprintf('\n');
fprintf('Winstmatrix L_opt =\n'); disp(L_opt);

%% ── 5. Simuleer observer op kalibratiedata ───────────────────────────────
xhat_opt = zeros(4, N_csv);
xhat_k   = [y_csv(1,1); 0; y_csv(2,1); 0];

for k = 1:N_csv
    xhat_opt(:,k) = xhat_k;
    y_k    = y_csv(:,k);
    yhat_k = C_d * xhat_k;
    xhat_k = A_d * xhat_k + B_d * u_csv(k) + L_opt * (y_k - yhat_k);
end

e_v_opt  = v_ref'     - xhat_opt(2,:);
e_om_opt = omega_ref' - xhat_opt(4,:);

fprintf('RMS fouten optimale observer:\n');
fprintf('  RMS fout x_dot:     %.5f m/s\n',   sqrt(mean(e_v_opt.^2)));
fprintf('  RMS fout theta_dot: %.5f rad/s\n\n', sqrt(mean(e_om_opt.^2)));

%% ── 6. Validatieplot ────────────────────────────────────────────────────
% FIX: 'Interpreter','none' vermijdt backslash-warnings in ylabel/title

figure('Name','ObserverOpt: Validatie optimale Polen','NumberTitle','off');

subplot(2,2,1);
    plot(t_csv, x_ref,           'DisplayName','Werkelijk'); hold on;
    plot(t_csv, y_csv(1,:).',    'DisplayName','Gemeten');
    plot(t_csv, xhat_opt(1,:).','--','DisplayName','Observer (opt)');
    ylabel('x (m)',              'Interpreter','none');
    xlabel('Tijd (s)');
    title('Positie x [gemeten]', 'Interpreter','none');
    legend('Location','best'); grid on;

subplot(2,2,2);
    plot(t_csv, v_ref,            'DisplayName','Werkelijk'); hold on;
    plot(t_csv, xhat_opt(2,:).','--','DisplayName','Observer (opt)');
    ylabel('x_dot (m/s)',                    'Interpreter','none');
    xlabel('Tijd (s)');
    title('Snelheid x_dot [NIET gemeten]',   'Interpreter','none');
    legend('Location','best'); grid on;

subplot(2,2,3);
    plot(t_csv, phi_ref,          'DisplayName','Werkelijk'); hold on;
    plot(t_csv, y_csv(2,:).',     'DisplayName','Gemeten');
    plot(t_csv, xhat_opt(3,:).','--','DisplayName','Observer (opt)');
    ylabel('theta (rad)',              'Interpreter','none');
    xlabel('Tijd (s)');
    title('Hoek theta [gemeten]',      'Interpreter','none');
    legend('Location','best'); grid on;

subplot(2,2,4);
    plot(t_csv, omega_ref,        'DisplayName','Werkelijk'); hold on;
    plot(t_csv, xhat_opt(4,:).','--','DisplayName','Observer (opt)');
    ylabel('theta_dot (rad/s)',                    'Interpreter','none');
    xlabel('Tijd (s)');
    title('Hoeksnelheid theta_dot [NIET gemeten]', 'Interpreter','none');
    legend('Location','best'); grid on;

sgtitle(sprintf('ObserverOpt: Optimale Polen [%.3f, %.3f, %.3f, %.3f]  J=%.4f', ...
    P_obs_opt, best_J), 'Interpreter','none');

%% ── 7. Sensitiviteitsplot — univariabel per pool ────────────────────────
%
% Voor elke pool i: beweeg p_i over [0.01, 0.99] terwijl de andere 3
% Polen op hun optimale waarde blijven. Zo zie je of het fmincon-optimum
% echt een minimum is in elke richting afzonderlijk.
%
fprintf('Sensitiviteitsanalyse (univariabel per pool)...\n');

p_sweep  = linspace(0.02, 0.98, 300);
J_per_pool = zeros(4, length(p_sweep));
pool_labels = {'p1 (traagste)', 'p2', 'p3', 'p4 (snelste)'};

for i = 1:4
    for ii = 1:length(p_sweep)
        p_test = P_obs_opt;          % start van optimum
        p_test(i) = p_sweep(ii);     % beweeg enkel pool i

        % Sla over als twee Polen samenvallen (place mislukt)
        diffs = abs(p_test(i) - p_test([1:i-1, i+1:4]));
        if any(diffs < 0.004)
            J_per_pool(i, ii) = NaN;
            continue;
        end
        J_per_pool(i, ii) = cost_fun(p_test);
    end
end

colors = lines(4);
figure('Name','Sensitiviteit J per pool (univariabel)','NumberTitle','off');
for i = 1:4
    subplot(2,2,i);
    plot(p_sweep, J_per_pool(i,:), 'Color', colors(i,:), 'LineWidth', 1.5);
    hold on;
    xline(P_obs_opt(i), 'r--', sprintf('Opt %.4f', P_obs_opt(i)), ...
        'LineWidth', 1.5, 'LabelVerticalAlignment','bottom');
    xlabel('Poolpositie p_i', 'Interpreter','none');
    ylabel('J',               'Interpreter','none');
    title(sprintf('Gevoeligheid voor %s', pool_labels{i}), 'Interpreter','none');
    grid on;
    ylim([0, min(max(J_per_pool(i, ~isnan(J_per_pool(i,:)))), 0.5)]);
end
sgtitle('Univariabele sensitiviteitsanalyse — rode lijn = fmincon optimum per pool', ...
    'Interpreter','none');

%% ── 8. Opslaan naar JSON ────────────────────────────────────────────────
obs_params_opt.A  = A_d;
obs_params_opt.B  = B_d;
obs_params_opt.C  = C_d;
obs_params_opt.L  = L_opt;
obs_params_opt.Ts = Ts;

output_file = 'observer_params.json';
fid = fopen(output_file, 'w');
if fid ~= -1
    fwrite(fid, jsonencode(obs_params_opt));
    fclose(fid);
    fprintf('Observer parameters opgeslagen in: %s\n', output_file);
end

fprintf('\nGebruik in Observer.m:\n');
fprintf('P_obs = [%.4f, %.4f, %.4f, %.4f];\n\n', P_obs_opt);
fprintf('============================================================\n');
fprintf('  KLAAR\n');
fprintf('============================================================\n');

%% ── Hulpfuncties ────────────────────────────────────────────────────────

function J = observer_cost(p, A_d, B_d, C_d, y_csv, u_csv, ...
                            v_ref, omega_ref, x_ref, phi_ref, ...
                            w_v, w_om, w_x, w_ph)
    try
        L_try = place(A_d', C_d', p)';
    catch
        J = 1e6;
        return
    end

    N    = size(y_csv, 2);
    xhat = [y_csv(1,1); 0; y_csv(2,1); 0];
    e_v  = zeros(1,N);  e_om = zeros(1,N);
    e_x  = zeros(1,N);  e_ph = zeros(1,N);

    for k = 1:N
        y_k    = y_csv(:,k);
        yhat_k = C_d * xhat;
        e_v(k)  = v_ref(k)     - xhat(2);
        e_om(k) = omega_ref(k) - xhat(4);
        e_x(k)  = x_ref(k)    - xhat(1);
        e_ph(k) = phi_ref(k)   - xhat(3);
        xhat = A_d * xhat + B_d * u_csv(k) + L_try * (y_k - yhat_k);
    end

    J = w_v  * sqrt(mean(e_v.^2))  ...
      + w_om * sqrt(mean(e_om.^2)) ...
      + w_x  * sqrt(mean(e_x.^2))  ...
      + w_ph * sqrt(mean(e_ph.^2));
end

function [c, ceq] = pole_separation(p)
    delta_min = 0.005;
    pairs = nchoosek(1:4, 2);
    c   = zeros(size(pairs,1), 1);
    ceq = [];
    for ii = 1:size(pairs,1)
        c(ii) = delta_min - abs(p(pairs(ii,1)) - p(pairs(ii,2)));
    end
end