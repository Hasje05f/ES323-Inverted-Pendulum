%% PID Controller Design — Inverted Pendulum (theta output, DISCREET)
%
% Systeem:  H_d(z) = theta(z) / F(z),  Ts = 0.05 s
%
%   Discrete open-lus polen:
%     p1 = 1.5671   <-- INSTABIEL (buiten eenheidscirkel)
%     p2 = 0.9929   <-- bijna op eenheidscirkel (trage pool)
%     p3 = 0.6366
%
%   Discrete open-lus nulpunten:
%     z1 = -0.9968
%     z2 =  1.0000
%
% Aanpak: stel de PID-regelaar direct in door 2 nulpunten en 2 extra
% controleurspolen vrij te kiezen in het z-vlak.
%
%   C(z) = K * (z - zc1)(z - zc2) / (z - pc1)(z - pc2)
%
% Vereiste: voer eerst MATLAB_Code.m uit zodat H_d en Ts in de workspace
%           staan.
% -------------------------------------------------------------------------

clc; close all;

fprintf('============================================================\n');
fprintf('  PID CONTROLLER DESIGN — discreet, theta output\n');
fprintf('  Ts = 0.05 s\n');
fprintf('============================================================\n\n');

H_theta_d = H_d(2,1);   % discrete overdracht theta/F

[p_ol, z_ol] = pzmap(H_theta_d);
fprintf('Discrete open-lus polen:\n');
for i = 1:length(p_ol)
    stabstr = '';
    if abs(p_ol(i)) > 1, stabstr = '  <-- INSTABIEL'; end
    fprintf('  p%d = %+.6f %+.6fi   |p|=%.4f%s\n', ...
        i, real(p_ol(i)), imag(p_ol(i)), abs(p_ol(i)), stabstr);
end
fprintf('Discrete open-lus nulpunten:\n');
for i = 1:length(z_ol)
    fprintf('  z%d = %+.6f %+.6fi\n', i, real(z_ol(i)), imag(z_ol(i)));
end
fprintf('\n');

% =========================================================================
%% PID-REGELAAR — pool-nulpunt plaatsing
%
% De algemene discrete PID-structuur heeft de vorm:
%
%   C(z) = K * (z - zc1)(z - zc2) / (z - pc1)(z - pc2)
%
% Kies:
%   zc1, zc2  — de 2 nulpunten van de regelaar  (reeel of complex conjugaat)
%   pc1, pc2  — de 2 extra regelaarspolen        (typisch klein: snel, stabiel)
%   K         — versterkingsfactor (past de open-lus root locus aan)
%
% Tips:
%   * Beide regelaarspolen moeten binnen de eenheidscirkel liggen.
%   * Een pool in pc=0 geeft een pure vertraging (computation delay).
%   * Zet nulpunten dicht bij open-lus instabiele/trage pool om te
%     compenseren, of gebruik de root locus om K te kiezen.
%   * Stabiliteitgrens gesloten lus: alle CL-Polen |z| < 1.
% =========================================================================

% --- KIES HIER JE REGELAAR PARAMETERS ---

zc1 = 0.8;     % nulpunt 1  (reeel voorbeeld: dicht bij trage pool p2)
zc2 = p_ol(3);     % nulpunt 2 (op de 3de pool)

pc1 = -0.7;      % regelaarspool 1  (pure vertraging)
pc2 = 1;      % regelaarspool 2

K   =  90.4+0.3; %91.3-0.3     % versterking

% -------------------------------------------------------------------------

% Bouw C(z) op als tf
num_C = K * poly([zc1, zc2]);           % K*(z-zc1)*(z-zc2)
den_C = poly([pc1, pc2]);               % (z-pc1)*(z-pc2)
C     = tf(num_C, den_C, Ts);

fprintf('Regelaar C(z):\n');
C
fprintf('  Nulpunten regelaar:  z = [%.4f, %.4f]\n', zc1, zc2);
fprintf('  Polen regelaar:      z = [%.4f, %.4f]\n', pc1, pc2);
fprintf('  Versterking K:       %.4f\n\n', K);

% Gesloten-lus systeem
sys_CL = feedback(C * H_theta_d, 1);
[p_CL, ~] = pzmap(sys_CL);

fprintf('Gesloten-lus Polen:\n');
all_stable = true;
for i = 1:length(p_CL)
    stabstr = '';
    if abs(p_CL(i)) > 1.01
        stabstr = '  <-- INSTABIEL!';
        all_stable = false;
    end
    fprintf('  p%d = %+.4f %+.4fi   |p|=%.4f%s\n', ...
        i, real(p_CL(i)), imag(p_CL(i)), abs(p_CL(i)), stabstr);
end
fprintf('\n');

if all_stable
    info = stepinfo(sys_CL);
    fprintf('  Stijgtijd  (10%%->90%%): %.3f s\n', info.RiseTime    * Ts);
    fprintf('  Insteltijd (2%%):       %.3f s\n',  info.SettlingTime * Ts);
    fprintf('  Overshoot:             %.2f %%\n\n', info.Overshoot);
else
    fprintf('  [!] Systeem NIET stabiel — pas parameters aan.\n\n');
end

% =========================================================================
%% PLOTS
% =========================================================================

th = linspace(0, 2*pi, 300);

% Open-lus root locus met regelaar
figure('Name','Root Locus open lus C(z)*H(z)','NumberTitle','off');
    rlocus(H_theta_d);
    title('Root Locus — H_d(z)');
    hold on;
    % plot(cos(th), sin(th), 'r--', 'LineWidth', 1.2, 'DisplayName', 'Eenheidscirkel');
    % legend('Root Locus', 'Eenheidscirkel', 'Location', 'best');
    legend('Root Locus', 'Location', 'best');

% Open-lus root locus met regelaar
figure('Name','Root Locus open lus C(z)*H(z)','NumberTitle','off');
    rlocus(C * H_theta_d);
    title('Root Locus — C(z) \cdot H_d(z)');
    hold on;
    % plot(cos(th), sin(th), 'r--', 'LineWidth', 1.2, 'DisplayName', 'Eenheidscirkel');
    % legend('Root Locus', 'Eenheidscirkel', 'Location', 'best');
    legend('Root Locus', 'Location', 'best');

% Gesloten-lus pool-nulpuntenkaart
figure('Name','CL Pool-Nulpuntenkaart','NumberTitle','off');
    pzmap(sys_CL);
    hold on;
    % plot(cos(th), sin(th), 'r--', 'LineWidth', 1.2);
    title('Gesloten-lus pool-nulpuntenkaart');

% Staprespons
figure('Name','Staprespons gesloten lus','NumberTitle','off');
    step(sys_CL, 2);
    title(sprintf('Discrete staprespons — K=%.4f, zc=[%.3f %.3f], pc=[%.3f %.3f]', ...
        K, zc1, zc2, pc1, pc2));
    ylabel('\theta (rad)'); xlabel('Samples');
    grid on;

% =========================================================================
%% OPSLAAN NAAR JSON (voor Python-simulator)
%
% De Python-simulator verwacht Kp, Ki, Kd via het 'classical' type.
% Hieronder worden de regelaarcoëfficiënten omgezet naar PID-equivalent
% via matching van de discrete tf-coëfficiënten.
%
% Alternatief: gebruik controller_type = 'state_feedback' of een custom
% implementatie als de simulator directe C(z)-coëfficiënten ondersteunt.
% =========================================================================

fprintf('--- Parameters opslaan ---\n');

params = struct();
params.controller_type = 'classical';
params.Kp = K;       % vereenvoudigd: pas aan indien simulator C(z) direct accepteert
params.Ki = 0;
params.Kd = 0;
params.w  = 0;       % setpoint theta = 0 rad

output_file = 'controller_params.json';
fid = fopen(output_file, 'w');
if fid == -1
    warning('Kon %s niet schrijven. Controleer de map.', output_file);
else
    fwrite(fid, jsonencode(params));
    fclose(fid);
    fprintf('  Opgeslagen in: %s\n', output_file);
    fprintf('  Voer nu python PENDULUM.py uit.\n');
end

fprintf('\n============================================================\n');
fprintf('  KLAAR — pas zc1, zc2, pc1, pc2, K aan en herrun (Ctrl+Enter)\n');
fprintf('============================================================\n');