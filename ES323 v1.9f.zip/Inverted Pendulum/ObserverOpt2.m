%% Observer Pole Optimisation — zoek optimale (a, b) voor P_obs = [a, a-b, a-2b, a-3b]
%
% Minimaliseert: sqrt(RMS(e_xdot)^2 + RMS(e_thetadot)^2)
% -------------------------------------------------------------------------

clc;
fprintf('============================================================\n');
fprintf('  OBSERVER POLE OPTIMISATION — 2D sweep over (a, b)\n');
fprintf('  P_obs = [a,  a-b,  a-2b,  a-3b]\n');
fprintf('============================================================\n\n');

%% Systeemmatrices ophalen
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;

%% CSV-data laden
 csv_dir = fullfile(dir, 'Simulations Flament', ...
     'Calibratie Observer State Feedback - PCl[0.80, 0.79, 0.78, 0.77] - Met noise');
 
try
    data_states       = readmatrix(fullfile(csv_dir, 'pendulum_states.csv'));
    data_inputs       = readmatrix(fullfile(csv_dir, 'pendulum_inputs.csv'));
    data_measurements = readmatrix(fullfile(csv_dir, 'pendulum_measurements.csv'));
    fprintf('CSV geladen vanuit: %s\n\n', csv_dir);
catch
    warning('CSV-map niet gevonden — probeer huidige map.');
    data_states       = readmatrix('pendulum_states.csv');
    data_inputs       = readmatrix('pendulum_inputs.csv');
    data_measurements = readmatrix('pendulum_measurements.csv');
end

v_csv     = data_states(:,2);
omega_csv = data_states(:,4);
y_csv     = data_measurements';
u_csv     = data_inputs(:,1);
N_csv     = size(data_states, 1);
%% Grid sweep: a van 0.1 tot 0.99, b van 0.005 tot 0.15
% Beperking: a - 3b > 0  =>  b < a/3
a_vec = 0.10 : 0.01 : 0.99;
b_vec = 0.005 : 0.01 : 0.30;

[A_grid, B_grid] = meshgrid(a_vec, b_vec);
Cost_grid = nan(size(A_grid));

fprintf('Grid sweep (%d x %d = %d evaluaties)...\n', ...
    length(a_vec), length(b_vec), numel(A_grid));

for i = 1:numel(A_grid)
    a_i = A_grid(i);
    b_i = B_grid(i);
    % Geldig domein: kleinste pool a-3b moet > 0 en < 1
    if (a_i - 3*b_i) <= 0 || (a_i - 3*b_i) >= 1
        Cost_grid(i) = NaN;
    else
        Cost_grid(i) = observer_cost(a_i, b_i, A_d, B_d, C_d, ...
                                     y_csv, u_csv, v_csv, omega_csv);
    end
end

% Vervang mislukte evaluaties (1e6) door NaN voor nette plot
Cost_grid(Cost_grid >= 1e4) = NaN;

%% Optimum zoeken
valid_mask = ~isnan(Cost_grid);
cost_valid = Cost_grid;
cost_valid(~valid_mask) = Inf;

[cost_best, idx_best] = min(cost_valid(:));
[row_best, col_best]  = ind2sub(size(Cost_grid), idx_best);
a_opt = A_grid(row_best, col_best);
b_opt = B_grid(row_best, col_best);
P_opt = [a_opt, a_opt-b_opt, a_opt-2*b_opt, a_opt-3*b_opt];
L_opt = place(A_d', C_d', P_opt)';

%% Resultaten
fprintf('\n============================================================\n');
fprintf('  OPTIMAAL RESULTAAT\n');
fprintf('============================================================\n');
fprintf('  a_opt    = %.4f\n', a_opt);
fprintf('  b_opt    = %.4f\n', b_opt);
fprintf('  P_obs    = [%.4f, %.4f, %.4f, %.4f]\n', P_opt(1), P_opt(2), P_opt(3), P_opt(4));
fprintf('  Kost     = %.6f\n\n', cost_best);
fprintf('  Winstmatrix L =\n');
disp(L_opt);

%% Fijn zoeken rondom optimum
fprintf('Fijn zoeken rondom (a=%.4f, b=%.4f), stap 0.001...\n', a_opt, b_opt);

da = 0.02; db = 0.01;
a_fine = max(0.01, a_opt - da) : 0.001 : min(0.99, a_opt + da);
b_fine = max(0.001, b_opt - db) : 0.001 : min(0.3, b_opt + db);

[Af, Bf]  = meshgrid(a_fine, b_fine);
Cf        = nan(size(Af));

for i = 1:numel(Af)
    ai = Af(i); bi = Bf(i);
    if (ai - 3*bi) <= 0 || (ai - 3*bi) >= 1
        Cf(i) = NaN;
    else
        Cf(i) = observer_cost(ai, bi, A_d, B_d, C_d, y_csv, u_csv, v_csv, omega_csv);
    end
end
Cf(Cf >= 1e4) = NaN;

cf_valid = Cf; cf_valid(isnan(Cf)) = Inf;
[cost_fine, idx_fine] = min(cf_valid(:));
[rf, cf_idx]          = ind2sub(size(Cf), idx_fine);
a_fine_opt = Af(rf, cf_idx);
b_fine_opt = Bf(rf, cf_idx);
P_fine     = [a_fine_opt, a_fine_opt-b_fine_opt, a_fine_opt-2*b_fine_opt, a_fine_opt-3*b_fine_opt];


fprintf('\n============================================================\n');
fprintf('  FIJN OPTIMAAL RESULTAAT\n');
fprintf('============================================================\n');
fprintf('  a_opt    = %.4f\n', a_fine_opt);
fprintf('  b_opt    = %.4f\n', b_fine_opt);
fprintf('  P_obs    = [%.4f, %.4f, %.4f, %.4f]\n', P_fine(1), P_fine(2), P_fine(3), P_fine(4));
fprintf('  Kost     = %.6f\n\n', cost_fine);
fprintf('  Winstmatrix L =\n');
L_fine     = place(A_d', C_d', P_fine)';
disp(L_fine);

%% 3D oppervlakplot — grof
figure('Name', 'Observer Optimalisatie — 3D kostoppervlak (grof)', 'NumberTitle', 'off');
surf(A_grid, B_grid, Cost_grid, 'EdgeColor', 'none', 'FaceAlpha', 0.85);
hold on;
plot3(a_opt, b_opt, cost_best, 'r*', 'MarkerSize', 14, 'LineWidth', 2, ...
    'DisplayName', sprintf('Optimum (a=%.3f, b=%.3f)', a_opt, b_opt));
colormap(parula);
colorbar;
xlabel('$a$',            'Interpreter', 'latex', 'FontSize', 13);
ylabel('$b$',            'Interpreter', 'latex', 'FontSize', 13);
zlabel('Gecombineerde RMS-kost', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Kostoppervlak: P\\_obs = [a, a-b, a-2b, a-3b]  |  Optimum: a=%.4f, b=%.4f', ...
    a_opt, b_opt), 'Interpreter', 'none');
legend('Location', 'best');
view(-45, 30);
grid on;

%% 3D oppervlakplot — fijn
figure('Name', 'Observer Optimalisatie — 3D kostoppervlak (fijn)', 'NumberTitle', 'off');
surf(Af, Bf, Cf, 'EdgeColor', 'none', 'FaceAlpha', 0.85);
hold on;
plot3(a_fine_opt, b_fine_opt, cost_fine, 'r*', 'MarkerSize', 14, 'LineWidth', 2, ...
    'DisplayName', sprintf('Optimum (a=%.4f, b=%.4f)', a_fine_opt, b_fine_opt));
colormap(parula);
colorbar;
xlabel('$a$',            'Interpreter', 'latex', 'FontSize', 13);
ylabel('$b$',            'Interpreter', 'latex', 'FontSize', 13);
zlabel('Gecombineerde RMS-kost', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Fijn kostoppervlak  |  Optimum: a=%.4f, b=%.4f, kost=%.5f', ...
    a_fine_opt, b_fine_opt, cost_fine), 'Interpreter', 'none');
legend('Location', 'best');
view(-45, 30);
grid on;

fprintf('\n============================================================\n');
fprintf('  Klaar — kopieer P_obs naar Observer.m\n');
fprintf('============================================================\n');
%% Kostfunctie
function cost = observer_cost(a, b, A_d, B_d, C_d, y_csv, u_csv, v_csv, omega_csv)
    P_obs = [a, a-b, a-2*b, a-3*b];
    N = size(y_csv, 2);

    % Alle Polen moeten binnen eenheidscirkel liggen
    if any(abs(P_obs) >= 1) || any(abs(P_obs) <= 0)
        cost = 1e6; return;
    end

    % Polen mogen niet te dicht bij elkaar liggen (place() wordt instabiel)
    if b < 1e-4
        cost = 1e6; return;
    end

    try
        L = place(A_d', C_d', P_obs)';
    catch
        cost = 1e6; return;
    end

    if any(abs(eig(A_d - L*C_d)) >= 1)
        cost = 1e6; return;
    end

    % Observer simulatie
    xhat_k = [y_csv(1,1); 0; y_csv(2,1); 0];
    xhat   = zeros(4, N);
    for k = 1:N
        xhat(:,k) = xhat_k;
        xhat_k = A_d * xhat_k + B_d * u_csv(k) + L * (y_csv(:,k) - C_d * xhat_k);
    end

    e_v     = v_csv'     - xhat(2,:);
    e_omega = omega_csv' - xhat(4,:);
    cost    = sqrt(mean(e_v.^2) + mean(e_omega.^2));
end