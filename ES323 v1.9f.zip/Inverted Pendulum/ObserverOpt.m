%% Observer Pole Optimisation — zoek optimale 'a' voor P_obs = [a, a-0.01, a-0.02, a-0.03]
%
% Vereisten: sys_d, Ts, en CSV-bestanden aanwezig (zie Observer.m)
%
% Minimaliseert: sqrt(RMS(e_xdot)^2 + RMS(e_thetadot)^2)
% -------------------------------------------------------------------------

clc;
fprintf('============================================================\n');
fprintf('  OBSERVER POLE OPTIMISATION\n');
fprintf('  Zoekt optimale a in P_obs = [a, a-0.01, a-0.02, a-0.03]\n');
fprintf('============================================================\n\n');

%% Systeemmatrices ophalen
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;

%% CSV-data laden (zelfde pad als Observer.m — pas aan indien nodig)
% csv_dir = fullfile(dir, 'Simulations Flament', ...
    % 'Controller 2.0 (ExtStFb) - [-0.25, 0.0, 0.05, 0.0] - PE[0.63, 0.62, 0.61, 0.60, 0.98] - w = 0.25');

 % csv_dir = fullfile(dir, 'Simulations Flament', ...
 %     'Calibratie Observer State Feedback - PCl[0.75, 0.74, 0.73, 0.72]');

 csv_dir = fullfile(dir, 'Simulations Flament', ...
     'Calibratie Observer State Feedback - PCl[0.83, 0.82, 0.81, 0.80]');
 
 % csv_dir = fullfile(dir, 'Simulations Flament', ...
     % 'Calibratie Observer Extended State Feedback - PE = [0.85, 0.825, 0.8, 0.775,  0.75]');
 

try
    data_states       = readmatrix(fullfile(csv_dir, 'pendulum_states.csv'));
    data_inputs       = readmatrix(fullfile(csv_dir, 'pendulum_inputs.csv'));
    data_measurements = readmatrix(fullfile(csv_dir, 'pendulum_measurements.csv'));
    fprintf('CSV geladen vanuit: %s\n\n', csv_dir);
catch
    warning('CSV-map niet gevonden — probeer huidige map.');
    data_states       = readmatrix('pendulum_states.csv');
    data_inputs       = readmatrix('pendulum_inputs.csv');
    data_measurements = readmatrix('pendulum_measurements.csv');
end

N_csv = size(data_states, 1);

x_csv     = data_states(:,1);
v_csv     = data_states(:,2);
phi_csv   = data_states(:,3);
omega_csv = data_states(:,4);

y_csv     = data_measurements';   % 2 x N
u_csv     = data_inputs(:,1);

%% Grof zoekbereik: a van 0.04 tot 0.99 (zodat a-0.03 >= 0.01)
a_min  = 0.04;
a_max  = 0.99;
a_step = 0.01;
a_vec  = a_min : a_step : a_max;

costs  = zeros(size(a_vec));

fprintf('Grof zoeken (stap = %.3f)...\n', a_step);
for i = 1:length(a_vec)
    costs(i) = observer_cost(a_vec(i), A_d, B_d, C_d, y_csv, u_csv, v_csv, omega_csv, x_csv, phi_csv);
end

[~, idx_best_coarse] = min(costs);
a_best_coarse = a_vec(idx_best_coarse);
fprintf('  Beste a (grof):  %.4f  |  Kost: %.6f\n\n', a_best_coarse, costs(idx_best_coarse));

%% Fijn zoeken rondom beste grove waarde (±0.02, stap 0.001)
a_fine_min = max(a_min, a_best_coarse - 0.02);
a_fine_max = min(a_max, a_best_coarse + 0.02);
a_fine_vec = a_fine_min : 0.001 : a_fine_max;

costs_fine = zeros(size(a_fine_vec));

fprintf('Fijn zoeken rondom a = %.4f (stap = 0.001)...\n', a_best_coarse);
for i = 1:length(a_fine_vec)
    costs_fine(i) = observer_cost(a_vec(i), A_d, B_d, C_d, y_csv, u_csv, v_csv, omega_csv, x_csv, phi_csv);
end

[cost_best, idx_best_fine] = min(costs_fine);
a_opt  = a_fine_vec(idx_best_fine);
P_opt  = [a_opt, a_opt-0.01, a_opt-0.02, a_opt-0.03];
L_opt  = place(A_d', C_d', P_opt)';

%% Resultaten
fprintf('\n============================================================\n');
fprintf('  OPTIMAAL RESULTAAT\n');
fprintf('============================================================\n');
fprintf('  a_opt    = %.4f\n', a_opt);
fprintf('  P_obs    = [%.4f, %.4f, %.4f, %.4f]\n', P_opt(1), P_opt(2), P_opt(3), P_opt(4));
fprintf('  Kost     = %.6f  (gecombineerde RMS)\n\n', cost_best);
fprintf('  Winstmatrix L =\n');
disp(L_opt);

%% Plot kostkromme (grof + fijn)
figure('Name', 'Observer Pole Optimisation', 'NumberTitle', 'off');

subplot(2,1,1);
    plot(a_vec, costs, 'b-o', 'MarkerSize', 4);
    xline(a_opt, 'r--', sprintf('a = %.4f', a_opt), 'LabelVerticalAlignment', 'bottom');
    xlabel('$a$', 'Interpreter', 'latex');
    ylabel('Gecombineerde RMS-kost', 'Interpreter', 'latex');
    title('Grof zoeken: kost vs $a$', 'Interpreter', 'latex');
    grid on;

subplot(2,1,2);
    plot(a_fine_vec, costs_fine, 'b-o', 'MarkerSize', 4);
    xline(a_opt, 'r--', sprintf('a_{opt} = %.4f', a_opt), 'LabelVerticalAlignment', 'bottom');
    xlabel('$a$', 'Interpreter', 'latex');
    ylabel('Gecombineerde RMS-kost', 'Interpreter', 'latex');
    title('Fijn zoeken: kost vs $a$', 'Interpreter', 'latex');
    grid on;

sgtitle(sprintf('Observer Optimalisatie: P\\_obs = [%.3f, %.3f, %.3f, %.3f]', P_opt), ...
    'Interpreter', 'none');

fprintf('============================================================\n');
fprintf('  Klaar — kopieer P_obs naar Observer.m\n');
fprintf('============================================================\n');

%% Kostfunctie: gecombineerde RMS-fout op niet-gemeten toestanden
function cost = observer_cost(a, A_d, B_d, C_d, y_csv, u_csv, v_csv, omega_csv, x_csv, phi_csv)
    P_obs = [a, a-0.01, a-0.02, a-0.03];
    N = size(y_csv, 2);

    % Controleer stabiliteit en observeerbaarheid
    try
        % place() gooit een fout als Polen buiten eenheidscirkel of dubbel
        L = place(A_d', C_d', P_obs)';
    catch
        cost = 1e6;
        return;
    end

    % Controleer stabiliteit van observer
    if any(abs(eig(A_d - L*C_d)) >= 1)
        cost = 1e6;
        return;
    end

    % Observer simulatie
    xhat_k = [y_csv(1,1); 0; y_csv(2,1); 0];
    xhat   = zeros(4, N);

    for k = 1:N
        xhat(:, k) = xhat_k;
        yhat_k = C_d * xhat_k;
        xhat_k = A_d * xhat_k + B_d * u_csv(k) + L * (y_csv(:,k) - yhat_k);
    end

    e_v     = v_csv'     - xhat(2,:);
    e_omega = omega_csv' - xhat(4,:);

    e_x     = x_csv'     - xhat(1,:);
    e_phi = phi_csv' - xhat(3,:);

    rms_v     = sqrt(mean(e_v.^2));
    rms_omega = sqrt(mean(e_omega.^2));

    rms_x     = sqrt(mean(e_x.^2));
    rms_phi = sqrt(mean(e_phi.^2));

    cost      = sqrt(rms_v^2 + rms_omega^2);
end