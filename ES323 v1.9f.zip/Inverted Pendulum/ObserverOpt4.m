%% ObserverOpt.m — Observer-pooloptimalisatie via GESLOTEN-LUS simulatie
%
% WAAROM de vorige versie faalde:
%   De vorige kostfunctie minimaliseerde de state-schattingsfout op data
%   gegenereerd met een ideale observer. Die data is niet representatief
%   voor de echte gesloten lus (met ruis + suboptimale observer), waardoor
%   een trage pool (p=0.99) optimaal leek maar in Python catastrofaal was.
%
% CORRECTE AANPAK:
%   Simuleer de volledige gesloten lus in MATLAB (met ruis) en minimaliseer
%   de werkelijke tracking-performance. Geen Python nodig.
%
%   Gesloten-lus model (per tijdstap k):
%     Meting:    y_k   = C_d * x_k + ruis
%     Sturing:   u_k   = clip(Nbar*w - K*x_hat_k,  -F_max, F_max)
%     Systeem:   x_{k+1} = A_d * x_k   + B_d * u_k
%     Observer:  x_hat_{k+1} = A_d * x_hat_k + B_d * u_k
%                             + L * (y_k - C_d * x_hat_k)
%
%   Kostfunctie (gesloten lus):
%     J = w_x * RMS(x - w_ref)          <- tracking kartpositie
%       + w_th * RMS(theta)             <- pendelstabiliteit
%       + w_u  * RMS(u) / F_max        <- stuurkracht (niet te agressief)
%
%   Monte Carlo: gemiddelde over N_mc ruisrealisaties → robuuste schatting
%
% Vereiste workspace-variabelen (na MATLAB_Code.m + StateFeedback.m):
%   sys_d, Ts, K, Nbar, w_x (setpoint), x0 (begintoestand)
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  OBSERVER POOL-OPTIMALISATIE — gesloten-lus kostfunctie\n');
fprintf('  Ts = %.3f s\n', Ts);
fprintf('============================================================\n\n');

%% ── 0. Systeemmatrices & controllerparameters ───────────────────────────
A_d  = sys_d.A;
B_d  = sys_d.B;
C_d  = sys_d.C;

% Controller (aanwezig na StateFeedback.m)
% K, Nbar, w_x  — worden uit workspace gelezen

%% ── 1. Simulatieparameters ──────────────────────────────────────────────
N_sim  = 400;                        % tijdstappen (20 s bij Ts=0.05)
F_max  = 9.0;                        % zelfde saturaite als Python [N]
x0_sim = [0; 0; 0.05; 0];           % begintoestand (zelfde als Python)
N_mc   = 30;                         % Monte Carlo herhalingen per evaluatie

% Ruisniveaus (zelfde als Python Pendulum.get_measurement)
sigma_x   = 0.01;    % positieruis [m]
sigma_phi = 0.005;   % hoekreuis   [rad]
Q_noise   = diag([sigma_x, sigma_phi].^2);

%% ── 2. Gesloten-lus kostfunctie ─────────────────────────────────────────
%
% Gewichten: w_x zwaarst (tracking is het doel),
%            w_th zorgt dat pendulum stabiel blijft,
%            w_u voorkomt dat de optimizer agressieve gains kiest
%            die in Python de kracht satureren.
%
w_x_cost  = 1.0;
w_th_cost = 0.5;
w_u_cost  = 0.2;

cost_fun_cl = @(p) cl_cost(p, A_d, B_d, C_d, K, Nbar, w_x, x0_sim, ...
                             N_sim, F_max, N_mc, Q_noise, ...
                             w_x_cost, w_th_cost, w_u_cost);

%% ── 3. Optimalisatie ────────────────────────────────────────────────────
%
% Grenzen: bovengrens ub = 0.90 < min(|P_cl|) = 0.65
%          zodat observer altijd sneller is dan de regelaar.
%          Dit voorkomt de trage pool op 0.99 die eerder ruis deed ophopen.
%
lb = 0.02 * ones(1,4);
ub = 0.90 * ones(1,4);   % <-- bewust lager dan kleinste regelaarspool

start_candidates = [
    0.70 0.55 0.40 0.25;
    0.60 0.50 0.35 0.20;
    0.50 0.40 0.30 0.15;
    0.45 0.35 0.25 0.10;
    0.80 0.60 0.40 0.20;
    0.55 0.45 0.30 0.15;
    0.40 0.35 0.25 0.10;
    0.40 0.45 0.25 0.30;
];

opts = optimoptions('fmincon', ...
    'Display',       'off', ...
    'MaxIterations', 600,   ...
    'TolFun',        1e-5,  ...
    'TolX',          1e-5);

fprintf('Optimalisatie gestart (%d startpunten, %d MC-runs/evaluatie)...\n\n', ...
    size(start_candidates,1), N_mc);
fprintf('  [Dit duurt ~1-3 minuten]\n\n');

best_J = inf;
best_p = [];

for s = 1:size(start_candidates, 1)
    p0 = start_candidates(s,:);
    try
        [p_s, J_s] = fmincon(cost_fun_cl, p0, [], [], [], [], lb, ub, ...
                              @pole_separation, opts);
        if J_s < best_J
            best_J = J_s;
            best_p = p_s;
        end
        fprintf('  Start %d: J = %.5f   Polen = [%.4f %.4f %.4f %.4f]\n', ...
            s, J_s, p_s(1), p_s(2), p_s(3), p_s(4));
    catch ME
        fprintf('  Start %d: mislukt (%s)\n', s, ME.message);
    end
end
fprintf('\n');

%% ── 4. Resultaat ────────────────────────────────────────────────────────
P_obs_opt = sort(best_p, 'descend');
L_opt     = place(A_d', C_d', P_obs_opt)';
p_check   = eig(A_d - L_opt * C_d);

fprintf('============================================================\n');
fprintf('  OPTIMALE OBSERVER-POLEN (gesloten-lus geoptimaliseerd)\n');
fprintf('============================================================\n');
fprintf('  P_obs_opt = [%.4f, %.4f, %.4f, %.4f]\n', P_obs_opt);
fprintf('  J_min     = %.5f\n\n', best_J);

fprintf('Verificatie eigenwaarden (A_d - L*C_d):\n');
for i = 1:4
    stabstr = '';
    if abs(p_check(i)) >= 1, stabstr = '  <-- INSTABIEL!'; end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_check(i)), imag(p_check(i)), abs(p_check(i)), stabstr);
end
fprintf('\n');
fprintf('Winstmatrix L_opt =\n'); disp(L_opt);

%% ── 5. Verificatie: simuleer gesloten lus met optimale L ─────────────────
%  Eén deterministische run (zonder ruis) voor vergelijkbare plot met Python
x_k    = x0_sim;
xhat_k = [x0_sim(1); 0; x0_sim(3); 0];
u_k    = 0;

x_cl   = zeros(4, N_sim);
u_cl   = zeros(1, N_sim);
xhat_cl = zeros(4, N_sim);

for k = 1:N_sim
    x_cl(:,k)    = x_k;
    xhat_cl(:,k) = xhat_k;

    y_k    = C_d * x_k;                          % zonder ruis (deterministisch)
    yhat_k = C_d * xhat_k;
    xhat_k = A_d * xhat_k + B_d * u_k + L_opt * (y_k - yhat_k);

    u_k = max(min(Nbar * w_x - K * xhat_k, F_max), -F_max);
    u_cl(k) = u_k;
    x_k = A_d * x_k + B_d * u_k;
end

t_cl = (0:N_sim-1) * Ts;

figure('Name','Gesloten lus: optimale observer (deterministisch)','NumberTitle','off');
subplot(3,1,1);
    plot(t_cl, x_cl(1,:),   'LineWidth', 1.5); hold on;
    yline(w_x, 'k--', 'DisplayName', 'Referentie');
    ylabel('x (m)',          'Interpreter','none');
    title(sprintf('Positie x — Observer Polen [%.3f %.3f %.3f %.3f]', P_obs_opt), ...
        'Interpreter','none');
    legend('x','w_{ref}','Location','best'); grid on;

subplot(3,1,2);
    plot(t_cl, x_cl(3,:), 'Color',[0.85 0.33 0.1], 'LineWidth', 1.5);
    ylabel('theta (rad)',    'Interpreter','none');
    title('Hoek pendulum',   'Interpreter','none'); grid on;

subplot(3,1,3);
    plot(t_cl, u_cl, 'Color',[0.2 0.7 0.2], 'LineWidth', 1.5);
    ylabel('F (N)',           'Interpreter','none');
    xlabel('Tijd (s)');
    title('Stuurkracht',     'Interpreter','none'); grid on;

%% ── 6. Univariabele sensitiviteitsplot (gesloten-lus J) ─────────────────
fprintf('Sensitiviteitsanalyse (gesloten-lus, univariabel)...\n');

p_sweep = linspace(0.03, 0.88, 178);   % minder punten: elke eval kost tijd
J_per_pool = NaN(4, length(p_sweep));
pool_labels = {'p1 (traagste)', 'p2', 'p3', 'p4 (snelste)'};

for i = 1:4
    for ii = 1:length(p_sweep)
        p_test = P_obs_opt;
        p_test(i) = p_sweep(ii);
        diffs = abs(p_test(i) - p_test([1:i-1, i+1:4]));
        if any(diffs < 0.003), continue; end
        J_per_pool(i, ii) = cost_fun_cl(p_test);
    end
    fprintf('  Pool %d klaar\n', i);
end

colors = lines(4);
figure('Name','Sensitiviteit gesloten lus per pool','NumberTitle','off');
for i = 1:4
    subplot(2,2,i);
    plot(p_sweep, J_per_pool(i,:), 'Color', colors(i,:), 'LineWidth', 1.5);
    hold on;
    xline(P_obs_opt(i), 'r--', sprintf('Opt %.3f', P_obs_opt(i)), ...
        'LineWidth', 1.5, 'LabelVerticalAlignment','bottom');
    xlabel('Poolpositie', 'Interpreter','none');
    ylabel('J (gesloten lus)', 'Interpreter','none');
    title(sprintf('Gevoeligheid %s', pool_labels{i}), 'Interpreter','none');
    grid on;
end
sgtitle('Gesloten-lus sensitiviteit — rode lijn = fmincon optimum', 'Interpreter','none');

%% ── 7. Opslaan naar JSON ────────────────────────────────────────────────
obs_params_opt.A  = A_d;
obs_params_opt.B  = B_d;
obs_params_opt.C  = C_d;
obs_params_opt.L  = L_opt;
obs_params_opt.Ts = Ts;

fid = fopen('observer_params.json', 'w');
if fid ~= -1
    fwrite(fid, jsonencode(obs_params_opt));
    fclose(fid);
    fprintf('\nObserver parameters opgeslagen in: observer_params.json\n');
end

fprintf('\nGebruik in Observer.m:\n');
fprintf('P_obs = [%.4f, %.4f, %.4f, %.4f];\n\n', P_obs_opt);
fprintf('============================================================\n');
fprintf('  KLAAR\n');
fprintf('============================================================\n');

%% ── Hulpfuncties ────────────────────────────────────────────────────────

function [c, ceq] = pole_separation(p)
    delta_min = 0.005;
    pairs = nchoosek(1:4, 2);
    c   = zeros(size(pairs,1), 1);
    ceq = [];
    for ii = 1:size(pairs,1)
        c(ii) = delta_min - abs(p(pairs(ii,1)) - p(pairs(ii,2)));
    end
end

function J = cl_cost(p, A_d, B_d, C_d, K, Nbar, w_ref, x0, ...
                          N_sim, F_max, N_mc, Q_noise, ...
                          w_x_cost, w_th_cost, w_u_cost)

        % Observer aanmaken
        try
            L_try = place(A_d', C_d', p)';
        catch
            J = 1e6;
            return
        end

        n_y = size(C_d, 1);
        J_mc = zeros(N_mc, 1);

        for mc = 1:N_mc
            x_k    = x0;
            xhat_k = [x0(1); 0; x0(3); 0];   % snelheden onbekend bij start
            u_k    = 0;

            e_x  = zeros(1, N_sim);
            e_th = zeros(1, N_sim);
            u_log = zeros(1, N_sim);

            for k = 1:N_sim
                % Meting + ruis
                noise_k = chol(Q_noise)' * randn(n_y, 1);
                y_k = C_d * x_k + noise_k;

                % Observer update
                yhat_k  = C_d * xhat_k;
                xhat_k  = A_d * xhat_k + B_d * u_k + L_try * (y_k - yhat_k);

                % Sturing
                u_k = Nbar * w_ref - K * xhat_k;
                u_k = max(min(u_k, F_max), -F_max);

                % Logging
                e_x(k)   = x_k(1) - w_ref;
                e_th(k)  = x_k(3);
                u_log(k) = u_k;

                % Systeemdynamica
                x_k = A_d * x_k + B_d * u_k;
            end

            J_mc(mc) = w_x_cost  * sqrt(mean(e_x.^2))       ...
                     + w_th_cost * sqrt(mean(e_th.^2))       ...
                     + w_u_cost  * sqrt(mean(u_log.^2)) / F_max;
        end

        J = mean(J_mc);   % gemiddelde over Monte Carlo runs
    end