%% ObserverOpt.m — Globale observer-pooloptimalisatie (gesloten-lus)
%
% STRATEGIE (3 lagen):
%   Laag 1 — particleswarm  : globale zoektocht, 100 deeltjes
%   Laag 2 — MultiStart LHS : 200 willekeurige startpunten (Latin Hypercube)
%   Laag 3 — fmincon        : lokale verfijning vanuit top-5 kandidaten
%
% KOSTFUNCTIE: gesloten-lus Monte Carlo simulatie (geen Python nodig)
%   J = w_x*RMS(x-w) + w_th*RMS(theta) + w_u*RMS(u)/F_max
%   Gemiddeld over N_mc ruisrealisaties → robuuste schatting
%
% Vereiste workspace (na MATLAB_Code.m + StateFeedback.m):
%   sys_d, Ts, K, Nbar, w_x, x0 (begintoestand)
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  GLOBALE OBSERVER-OPTIMALISATIE — gesloten-lus\n');
fprintf('  Ts = %.3f s\n', Ts);
fprintf('============================================================\n\n');

%% ── 0. Systeemmatrices ──────────────────────────────────────────────────
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;

%% ── 1. Simulatieparameters ──────────────────────────────────────────────
N_sim     = 400;
F_max     = 9.0;
x0_sim    = [0; 0; 0.05; 0];
N_mc      = 50;          % Monte Carlo runs per evaluatie (meer = stabieler)
sigma_x   = 0.01;
sigma_phi = 0.005;

% Kostgewichten
w_x_cost  = 1.0;
w_th_cost = 0.5;
w_u_cost  = 0.2;

% Poolbegrenzing: observer moet sneller zijn dan regelaar
lb = 0.01 * ones(1,4);
ub = 0.65 * ones(1,4);

% Minimale poolseparatie (voor place())
delta_min = 0.008;

%% ── 2. Kostfuncties ─────────────────────────────────────────────────────

  
% Snelkoppelingen met vaste parameters
pso_fun = @(p) cost_for_pso(p, A_d, B_d, C_d, K, Nbar, w_x, x0_sim, ...
                              N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                              w_x_cost, w_th_cost, w_u_cost, delta_min);

fmc_fun = @(p) cost_for_fmincon(p, A_d, B_d, C_d, K, Nbar, w_x, x0_sim, ...
                                  N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                                  w_x_cost, w_th_cost, w_u_cost);

%% ── 3. LAAG 1: Particle Swarm Optimization ──────────────────────────────
fprintf('--- Laag 1: Particle Swarm (100 deeltjes) ---\n');

pso_opts = optimoptions('particleswarm', ...
    'SwarmSize',        100,    ...
    'MaxIterations',    300,    ...
    'FunctionTolerance',1e-5,   ...
    'Display',          'iter', ...
    'PlotFcn',          @pswplotbestf);

[p_pso, J_pso] = particleswarm(pso_fun, 4, lb, ub, pso_opts);
fprintf('\nPSO resultaat: J = %.5f   Polen = [%.4f %.4f %.4f %.4f]\n\n', ...
    J_pso, p_pso(1), p_pso(2), p_pso(3), p_pso(4));

%% ── 4. LAAG 2: MultiStart met Latin Hypercube Sampling ──────────────────
fprintf('--- Laag 2: MultiStart met LHS (200 startpunten) ---\n');

N_lhs = 200;
% Latin Hypercube Sampling: uniforme spreiding over [lb, ub]
rng(42);   % reproduceerbaar
lhs_raw   = lhsdesign(N_lhs, 4);                   % uniforme [0,1]
lhs_pts   = lb + lhs_raw .* (ub - lb);             % schaal naar [lb, ub]

% Filter: verwijder punten waar Polen te dicht bij elkaar zitten
valid_mask = false(N_lhs, 1);
for s = 1:N_lhs
    p_s = lhs_pts(s,:);
    pairs = nchoosek(1:4, 2);
    diffs = arrayfun(@(r) abs(p_s(pairs(r,1)) - p_s(pairs(r,2))), 1:size(pairs,1));
    if all(diffs >= delta_min)
        valid_mask(s) = true;
    end
end
lhs_valid = lhs_pts(valid_mask, :);
fprintf('  %d van %d LHS-punten geldig (poolseparatie OK)\n\n', ...
    sum(valid_mask), N_lhs);

opts_lhs = optimoptions('fmincon', ...
    'Display',       'off', ...
    'MaxIterations', 200,   ...
    'TolFun',        1e-5,  ...
    'TolX',          1e-5);

J_lhs  = inf(size(lhs_valid,1), 1);
p_lhs  = zeros(size(lhs_valid,1), 4);

fprintf('  Evaluatie LHS-startpunten (kan even duren)...\n');
for s = 1:size(lhs_valid,1)
    try
        [p_s, J_s] = fmincon(fmc_fun, lhs_valid(s,:), [], [], [], [], ...
                              lb, ub, @pole_separation, opts_lhs);
        J_lhs(s)   = J_s;
        p_lhs(s,:) = p_s;
    catch
        % startpunt leidde tot fout — sla over
    end
    if mod(s,20) == 0
        fprintf('  [%d/%d]  huidig beste J = %.5f\n', s, size(lhs_valid,1), min(J_lhs));
    end
end
[J_lhs_best, idx_lhs] = min(J_lhs);
p_lhs_best = p_lhs(idx_lhs,:);
fprintf('\nLHS resultaat: J = %.5f   Polen = [%.4f %.4f %.4f %.4f]\n\n', ...
    J_lhs_best, p_lhs_best(1), p_lhs_best(2), p_lhs_best(3), p_lhs_best(4));

%% ── 5. LAAG 3: fmincon verfijning top-5 kandidaten ──────────────────────
fprintf('--- Laag 3: fmincon verfijning top-5 kandidaten ---\n');

% Verzamel alle kandidaten: PSO + top-5 LHS
[J_lhs_sorted, sort_idx] = sort(J_lhs);
top5_pts = [p_pso; p_lhs(sort_idx(1:min(4, end)),:)];
top5_J   = [J_pso; J_lhs_sorted(1:min(4,end))];

opts_refine = optimoptions('fmincon', ...
    'Display',       'off', ...
    'MaxIterations', 500,   ...
    'TolFun',        1e-7,  ...
    'TolX',          1e-7);

best_J = inf;
best_p = [];

for s = 1:size(top5_pts,1)
    try
        [p_s, J_s] = fmincon(fmc_fun, top5_pts(s,:), [], [], [], [], ...
                              lb, ub, @pole_separation, opts_refine);
        if J_s < best_J
            best_J = J_s;
            best_p = p_s;
        end
        fprintf('  Kandidaat %d: J = %.5f → J_verfijnd = %.5f   Polen = [%.4f %.4f %.4f %.4f]\n', ...
            s, top5_J(s), J_s, p_s(1), p_s(2), p_s(3), p_s(4));
    catch ME
        fprintf('  Kandidaat %d: mislukt (%s)\n', s, ME.message);
    end
end
fprintf('\n');

%% ── 6. Eindresultaat ────────────────────────────────────────────────────
P_obs_opt = sort(best_p, 'descend');
L_opt     = place(A_d', C_d', P_obs_opt)';
p_check   = eig(A_d - L_opt * C_d);

fprintf('============================================================\n');
fprintf('  GLOBAAL OPTIMALE OBSERVER-POLEN\n');
fprintf('============================================================\n');
fprintf('  P_obs_opt = [%.4f, %.4f, %.4f, %.4f]\n', P_obs_opt);
fprintf('  J_min     = %.5f\n\n', best_J);
fprintf('  Vergelijking startmethoden:\n');
fprintf('    PSO best:    J = %.5f\n', J_pso);
fprintf('    LHS best:    J = %.5f\n', J_lhs_best);
fprintf('    Verfijnd:    J = %.5f  ← gebruikt\n\n', best_J);

fprintf('Verificatie eigenwaarden (A_d - L*C_d):\n');
all_stable = true;
for i = 1:4
    stabstr = '';
    if abs(p_check(i)) >= 1, stabstr = '  <-- INSTABIEL!'; all_stable = false; end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_check(i)), imag(p_check(i)), abs(p_check(i)), stabstr);
end
fprintf('\n');
if ~all_stable, error('Observer niet stabiel — controleer grenzen.'); end
fprintf('Winstmatrix L_opt =\n'); disp(L_opt);

%% ── 7. Gesloten-lus verificatieplot (deterministisch) ───────────────────
x_k    = x0_sim;
xhat_k = [x0_sim(1); 0; x0_sim(3); 0];
u_k    = 0;
x_cl   = zeros(4, N_sim);
u_cl   = zeros(1, N_sim);

for k = 1:N_sim
    x_cl(:,k) = x_k;
    y_k    = C_d * x_k;
    yhat_k = C_d * xhat_k;
    xhat_k = A_d * xhat_k + B_d * u_k + L_opt * (y_k - yhat_k);
    u_k    = max(min(Nbar * w_x - K * xhat_k, F_max), -F_max);
    u_cl(k) = u_k;
    x_k    = A_d * x_k + B_d * u_k;
end

t_cl = (0:N_sim-1) * Ts;

figure('Name','Gesloten lus — optimale observer','NumberTitle','off');
subplot(3,1,1);
    plot(t_cl, x_cl(1,:), 'LineWidth', 1.5); hold on;
    yline(w_x, 'k--');
    ylabel('x (m)',          'Interpreter','none');
    title(sprintf('Positie — Observer Polen [%.3f %.3f %.3f %.3f]  J=%.4f', ...
        P_obs_opt, best_J), 'Interpreter','none');
    legend('x','w_{ref}','Location','best'); grid on;

subplot(3,1,2);
    plot(t_cl, x_cl(3,:), 'Color',[0.85 0.33 0.1], 'LineWidth', 1.5);
    ylabel('theta (rad)',    'Interpreter','none');
    title('Hoek pendulum',   'Interpreter','none'); grid on;

subplot(3,1,3);
    plot(t_cl, u_cl, 'Color',[0.2 0.7 0.2], 'LineWidth', 1.5);
    ylabel('F (N)',           'Interpreter','none');
    xlabel('Tijd (s)');
    title('Stuurkracht',     'Interpreter','none'); grid on;

%% ── 8. Kostlandschap: 2D heatmap (pool 1 vs pool 2, rest op optimum) ────
fprintf('2D kostlandschap (pool 1 vs pool 2)...\n');

n_grid = 25;
p1_vec = linspace(lb(1), ub(1), n_grid);
p2_vec = linspace(lb(2), ub(2), n_grid);
J_map  = NaN(n_grid, n_grid);

for i = 1:n_grid
    for j = 1:n_grid
        p_test    = P_obs_opt;
        p_test(1) = p1_vec(i);
        p_test(2) = p2_vec(j);
        diffs = abs(p_test(1) - p_test(2:4));
        if any(diffs < delta_min), continue; end
        diffs2 = abs(p_test(2) - p_test(3:4));
        if any(diffs2 < delta_min), continue; end
        try
            L_t = place(A_d', C_d', p_test)';
            J_map(i,j) = cl_cost_core(L_t, A_d, B_d, C_d, K, Nbar, w_x, x0_sim, ...
                                       N_sim, F_max, 10, sigma_x, sigma_phi, ...
                                       w_x_cost, w_th_cost, w_u_cost);
        catch
        end
    end
end

figure('Name','2D kostlandschap p1 vs p2','NumberTitle','off');
    imagesc(p2_vec, p1_vec, J_map);
    set(gca,'YDir','normal');
    colorbar; colormap(jet);
    hold on;
    plot(P_obs_opt(2), P_obs_opt(1), 'w*', 'MarkerSize', 12, 'LineWidth', 2, ...
        'DisplayName', 'Optimum');
    xlabel('Pool 2', 'Interpreter','none');
    ylabel('Pool 1 (traagste)', 'Interpreter','none');
    title('Kostlandschap J (p3 en p4 op optimum)', 'Interpreter','none');
    legend('Location','best'); grid off;

%% ── 9. Univariabele sensitiviteitsplot ───────────────────────────────────
fprintf('Univariabele sensitiviteitsanalyse...\n');

p_sweep    = linspace(0.03, 0.88, 30);
J_per_pool = NaN(4, length(p_sweep));
pool_labels = {'p1 (traagste)', 'p2', 'p3', 'p4 (snelste)'};

for i = 1:4
    for ii = 1:length(p_sweep)
        p_test    = P_obs_opt;
        p_test(i) = p_sweep(ii);
        diffs = abs(p_test(i) - p_test([1:i-1, i+1:4]));
        if any(diffs < delta_min), continue; end
        try
            L_t = place(A_d', C_d', p_test)';
            J_per_pool(i,ii) = cl_cost_core(L_t, A_d, B_d, C_d, K, Nbar, w_x, x0_sim, ...
                                              N_sim, F_max, 15, sigma_x, sigma_phi, ...
                                              w_x_cost, w_th_cost, w_u_cost);
        catch
        end
    end
end

colors = lines(4);
figure('Name','Sensitiviteit per pool (gesloten lus)','NumberTitle','off');
for i = 1:4
    subplot(2,2,i);
    plot(p_sweep, J_per_pool(i,:), 'Color', colors(i,:), 'LineWidth', 1.5);
    hold on;
    xline(P_obs_opt(i), 'r--', sprintf('Opt %.3f', P_obs_opt(i)), ...
        'LineWidth', 1.5, 'LabelVerticalAlignment','bottom');
    xlabel('Poolpositie',      'Interpreter','none');
    ylabel('J (gesloten lus)', 'Interpreter','none');
    title(sprintf('%s', pool_labels{i}), 'Interpreter','none');
    ylim([min(J_per_pool(i,~isnan(J_per_pool(i,:)))) * 0.9, ...
          min(max(J_per_pool(i,~isnan(J_per_pool(i,:)))), best_J * 3)]);
    grid on;
end
sgtitle('Univariabele gesloten-lus sensitiviteit — rode lijn = optimum', 'Interpreter','none');

%% ── 10. Opslaan naar JSON ───────────────────────────────────────────────
obs_params_opt.A  = A_d;
obs_params_opt.B  = B_d;
obs_params_opt.C  = C_d;
obs_params_opt.L  = L_opt;
obs_params_opt.Ts = Ts;

fid = fopen('observer_params.json', 'w');
if fid ~= -1
    fwrite(fid, jsonencode(obs_params_opt));
    fclose(fid);
end

fprintf('\nGebruik in Observer.m:\n');
fprintf('P_obs = [%.4f, %.4f, %.4f, %.4f];\n\n', P_obs_opt);
fprintf('============================================================\n');
fprintf('  KLAAR\n');
fprintf('============================================================\n');
%%
 % --- Gesloten-lus simulatie (kern) ---
    function J = cl_cost_core(L_try, A_d, B_d, C_d, K, Nbar, w_ref, x0, ...
                               N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                               w_x_cost, w_th_cost, w_u_cost)
        n_y   = size(C_d, 1);
        J_mc  = zeros(N_mc, 1);
        Q_chol = diag([sigma_x, sigma_phi]);

        for mc = 1:N_mc
            x_k    = x0;
            xhat_k = [x0(1); 0; x0(3); 0];
            u_k    = 0;
            e_x    = zeros(1, N_sim);
            e_th   = zeros(1, N_sim);
            u_log  = zeros(1, N_sim);

            for k = 1:N_sim
                y_k    = C_d * x_k + Q_chol * randn(n_y, 1);
                yhat_k = C_d * xhat_k;
                xhat_k = A_d * xhat_k + B_d * u_k + L_try * (y_k - yhat_k);
                u_k    = max(min(Nbar * w_ref - K * xhat_k, F_max), -F_max);
                e_x(k)   = x_k(1) - w_ref;
                e_th(k)  = x_k(3);
                u_log(k) = u_k;
                x_k = A_d * x_k + B_d * u_k;
            end

            J_mc(mc) = w_x_cost  * sqrt(mean(e_x.^2))          ...
                     + w_th_cost * sqrt(mean(e_th.^2))          ...
                     + w_u_cost  * sqrt(mean(u_log.^2)) / F_max;
        end
        J = mean(J_mc);
    end

    % --- Wrapper voor fmincon (met pole_separation constraint) ---
    function J = cost_for_fmincon(p, A_d, B_d, C_d, K, Nbar, w_ref, x0, ...
                                   N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                                   w_x_cost, w_th_cost, w_u_cost)
        try
            L_try = place(A_d', C_d', p)';
        catch
            J = 1e6; return
        end
        J = cl_cost_core(L_try, A_d, B_d, C_d, K, Nbar, w_ref, x0, ...
                         N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                         w_x_cost, w_th_cost, w_u_cost);
    end

    % --- Wrapper voor particleswarm (penalty ipv constraint) ---
    function J = cost_for_pso(p, A_d, B_d, C_d, K, Nbar, w_ref, x0, ...
                               N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                               w_x_cost, w_th_cost, w_u_cost, delta_min)
        % Straf voor Polen die te dicht bij elkaar liggen
        pairs  = nchoosek(1:4, 2);
        diffs  = arrayfun(@(r) abs(p(pairs(r,1)) - p(pairs(r,2))), 1:size(pairs,1));
        penalty = 1e4 * sum(max(0, delta_min - diffs).^2);
        if penalty > 0
            J = 1e4 + penalty; return
        end

        try
            L_try = place(A_d', C_d', p)';
        catch
            J = 1e6; return
        end
        J = cl_cost_core(L_try, A_d, B_d, C_d, K, Nbar, w_ref, x0, ...
                         N_sim, F_max, N_mc, sigma_x, sigma_phi, ...
                         w_x_cost, w_th_cost, w_u_cost) + penalty;
    end

    % --- Nonlinear constraint voor fmincon ---
    function [c, ceq] = pole_separation(p)
        pairs = nchoosek(1:4, 2);
        c   = arrayfun(@(r) delta_min - abs(p(pairs(r,1)) - p(pairs(r,2))), ...
                       1:size(pairs,1))';
        ceq = [];
    end