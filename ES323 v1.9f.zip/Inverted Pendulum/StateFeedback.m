%% State Feedback Controller Design — Inverted Pendulum (discreet)
%
% Vereiste: voer eerst MATLAB_Code.m uit zodat de volgende variabelen
%           in de workspace aanwezig zijn:
%               sys_d   — discreet toestandsruimtemodel (ss-object)
%               A, B, C, D  — continue systeemmatrices
%               Ts      — bemonsteringstijd (0.05 s)
%
% Toestandsvector:  x = [x;  x_dot;  theta;  theta_dot]
% Ingang:           u = F (kracht op kar)
% Uitgang:          y = [x; theta]
%
% -------------------------------------------------------------------------
% THEORIE (zie slides ES322):
%
%   Toestandsterugkoppeling:  u[k] = -K * x[k]
%   Gesloten-lus:             x[k+1] = (A_d - B_d*K) * x[k]
%   Polen GL = eigenwaarden van A_d - B_d*K
%
%   Setpoint via variabelenwijziging (slide 13-15):
%                           u - u_ss = K(x-x_ss)
%     In stationaire toestand:  x_ss = A_d*x_ss + B_d*u_ss
%                               y_ss = C0*x_ss = w
%     Oplossing:  x_ss = Nx*w,  u_ss = Nu*w
%                       Nx = -(A-I)^(-1*B0*Nu
%                       Nu = (-C0(A-I)^(-1)*B)^-1
%     Aansturing: u[k] = Nu*w - K*(x[k] - Nx*w)
%                       = (Nu + K*Nx)*w - K*x[k]
%
%   Met observer (scheidingsprincipe):
%     u[k] = (Nu + K*Nx)*w - K*x_hat[k]
%     De polen van het gecombineerd systeem zijn de unie van de
%     regelaar-polen (eig van A_d-B_d*K) en de observer-polen
%     (eig van A_d-L*C_d) — ze kunnen onafhankelijk ontworpen worden.
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  STATE FEEDBACK CONTROLLER DESIGN — discreet\n');
fprintf('  Ts = 0.05 s\n');
fprintf('============================================================\n\n');

%% Haal discrete systeemmatrices op
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;   % [1 0 0 0; 0 0 1 0]  — meet x en theta

% Voor setpoint: we regelen x (eerste uitgang)
% C0 = rij van C_d die overeenkomt met de te regelen uitgang y0 = x
C0 = C_d(1,:);   % [1 0 0 0]
B0 = B_d;        % enkele regelende ingang F

%% Controleer controleerbaarheid
Co = ctrb(A_d, B0);
fprintf('Rank controleerbaarheidsmatrix: %d (moet %d zijn)\n\n', ...
    rank(Co), size(A_d,1));

%% Open-lus polen (ter referentie)
p_ol = eig(A_d);
fprintf('Open-lus polen van A_d:\n');
for i = 1:length(p_ol)
    stabstr = '';
    if abs(p_ol(i)) > 1, stabstr = '  <-- INSTABIEL'; end
    fprintf('  p%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_ol(i)), imag(p_ol(i)), abs(p_ol(i)), stabstr);
end
fprintf('\n');

% =========================================================================
%% KEUZE VAN GESLOTEN-LUS POLEN
%
% Strategie:
%   - Alle 4 CL-polen moeten binnen de eenheidscirkel liggen (|p| < 1)
%   - De instabiele open-lus pool (|p| = 1.567) moet naar binnen gehaald worden
%   - Snellere polen (kleiner |p|) = snellere respons maar meer stuurkracht
%
%   Vergelijking met PID-gesloten-lus Polen (ter referentie):
%     PID had CL-Polen op: [1.00, 0.637, 0.376, 0.204, -0.078]
%     (5 Polen door 2de-orde regelaar + 3de-orde plant)
%     State feedback geeft exact 4 Polen — één per toestand.
%
% =========================================================================

% --- KIES HIER JE GESLOTEN-LUS POLEN ---
% P_cl = [0.95, 0.94, 0.93, 0.92];                            

P_cl = [0.85 0.8 0.7 0.65];

% P_cl = [0.9, 0.89, 0.88, 0.87];   
% P_cl = [0.85, 0.84, 0.83, 0.82];             
% P_cl = [0.83, 0.82, 0.81, 0.80];             % Beste State feedback [l = % 0.15, P_obs = [0.2, 0.19, 0.18, 0.17], geen rekening houdend met marge van F_max]
                                                    % en [l = l_opt, [0.05, 0.04, 0.03, 0.02], geen rekening houdend met marge van F_max]
% P_cl = [0.80, 0.79, 0.78, 0.77];            % Beste State feedback [l = l_opt, P_obs = [0.54, 0.53, 0.52, 0.51], rekening houdend met marge van F_max]
% P_cl = [0.77, 0.76, 0.75, 0.74];              % Beste State feedback [l = % 0.15, P_obs = [0.73,  0.72, 0.71, 0.70], rekening houdend met marge van F_max]

% P_cl = [0.75, 0.74, 0.73, 0.72];              % Convergentie kan sneller door meer kracht te gebruiken (Te trage polen)                 
% P_cl = [0.71, 0.7, 0.69, 0.68];              
% P_cl = [0.69, 0.68, 0.67, 0.66];              % Perfecte afweging convergentiesnelheid en gebruikte kracht
% P_cl = [0.66, 0.65, 0.64, 0.63];              % Snelste convergentie, maar kracht zeer dicht bij maximale toegelaten kracht (10N) (Te snelle polen)

% P_cl = [0.63, 0.62, 0.61, 0.6];               % In python raakt de kar de rand, waardoor de simulatie divergeert. (Extended state feedback polen)

%% Bereken winstmatrix K via place()
K = place(A_d, B_d, P_cl);

fprintf('Gewenste CL-Polen:\n');
for i = 1:length(P_cl)
    fprintf('  p_cl%d = %+.4f %+.4fi   |p| = %.4f\n', ...
        i, real(P_cl(i)), imag(P_cl(i)), abs(P_cl(i)));
end
fprintf('\n');

%% Verifieer eigenwaarden van (A_d - B_d*K)
A_cl = A_d - B_d * K;
p_cl_check = eig(A_cl);

fprintf('Winstmatrix K =\n');
disp(K);

fprintf('Verificatie eigenwaarden van (A_d - B_d*K):\n');
all_stable = true;
for i = 1:length(p_cl_check)
    stabstr = '';
    if abs(p_cl_check(i)) >= 1
        stabstr = '  <-- INSTABIEL!';
        all_stable = false;
    end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_cl_check(i)), imag(p_cl_check(i)), abs(p_cl_check(i)), stabstr);
end
fprintf('\n');

if ~all_stable
    fprintf('  [!] Systeem NIET stabiel — pas P_cl aan.\n\n');
    return;
end

% =========================================================================
%% SETPOINT VIA VARIABELENWIJZIGING (slides ES322, slide 13-15)
%
% We willen de kar naar positie w_x sturen terwijl theta -> 0.
% Te regelen uitgang: y0 = x  (eerste uitgang, C0 = [1 0 0 0])
%
% In stationaire toestand moet gelden:
%   x_ss = A_d * x_ss + B_d * u_ss   (toestandsvergelijking)
%   w_x  = C0  * x_ss                 (gewenste uitgang)
%
% Dit geeft het stelsel (slide 15):
%   [A_d - I,  B_d ] [Nx]   [0]
%   [C0,       0   ] [Nu] = [1]
%
% Oplossing: Nx (4x1) en Nu (scalar)
% Aansturing met setpoint: u = (Nu + K*Nx)*w_x - K*x_hat
%                            = Nbar * w_x - K * x_hat
% =========================================================================

fprintf('--- Setpoint berekening (Nx, Nu) ---\n\n');

% Stelsel opstellen
n  = size(A_d, 1);   % 4
Z  = [A_d - eye(n),  B_d;
      C0,            zeros(1, size(B_d,2))];
rhs = [zeros(n,1); 1];

% Oplossing
NxNu = Z \ rhs;
Nx = NxNu(1:n);        % 4x1 toestandsoffset per eenheid setpoint
Nu = NxNu(n+1:end);    % scalar ingangsoffset

Nbar = Nu + K * Nx;    % gecombineerde voorwaartse versterkingsfactor

fprintf('  Nx = [%.4f; %.4f; %.4f; %.4f]\n', Nx(1), Nx(2), Nx(3), Nx(4));
fprintf('  Nu = %.4f\n', Nu);
fprintf('  Nbar = Nu + K*Nx = %.4f\n\n', Nbar);
fprintf('  Aansturing: u[k] = Nbar * w_x - K * x_hat[k]\n\n');

% =========================================================================
%% SIMULATIE (zonder observer — ideaal geval: toestanden volledig gekend)
%
% We simuleren het gesloten-lus systeem met u = Nbar*w - K*x
% (alsof alle toestanden gemeten worden).
% Begintoestand: kar op x=-0.25 m, pendulum lichtjes schuin theta=0.05 rad.
% Setpoint: w_x = 0 (kar naar midden brengen).
%
% Later wordt dit vervangen door u = Nbar*w - K*x_hat (met observer).
% =========================================================================

fprintf('--- Simulatie (ideaal: alle toestanden gekend) ---\n\n');

w_x   = 0.25;                          % setpoint kartpositie [m]
x0    = [-0; 0; 0.05; 0];           % begintoestand %-0.25
N_sim = 400;                           % tijdstappen
F_max = 9.0;                           % saturatie [N]

x_sim = zeros(4, N_sim);
u_sim = zeros(1, N_sim);
x_k   = x0;

for k = 1:N_sim
    x_sim(:, k) = x_k;

    % Saturatie (simuleer max_F van Python-simulator)
    u_k = max(min(Nbar * w_x - K * x_k, F_max), -F_max);
    u_sim(k) = u_k;

    % Systeem update (lineair model)
    x_k = A_d * x_k + B_d * u_k;
end

t_sim = (0:N_sim-1) * Ts;

% %% PLOTS simulatie
% figure('Name','State Feedback: toestandsrespons','NumberTitle','off');
% 
% subplot(2,2,1);
%     plot(t_sim, x_sim(1,:), 'LineWidth', 1.5); hold on;
%     % yline(w_x, 'r--', 'Setpoint');
%     ylabel('x  (m)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
%     title('Positie  x', 'Interpreter', 'latex'); grid on;
% 
% subplot(2,2,2);
%     plot(t_sim, x_sim(2,:), 'LineWidth', 1.5);
%     ylabel('$\dot{x}$  (m/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
%     title('Snelheid  $\dot{x}$', 'Interpreter', 'latex'); grid on;
% 
% subplot(2,2,3);
%     plot(t_sim, x_sim(3,:), 'LineWidth', 1.5); hold on;
%     % yline(0, 'r--', '\theta = 0');
%     ylabel('$\theta$  (rad)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
%     title('Hoek  $\theta$', 'Interpreter', 'latex'); grid on;
% 
% subplot(2,2,4);
%     plot(t_sim, x_sim(4,:), 'LineWidth', 1.5);
%     ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
%     title('Hoeksnelheid  $\dot{\theta}$', 'Interpreter', 'latex'); grid on;
% 
% sgtitle(sprintf('State Feedback — CL-Polen: [%.3f %.3f %.3f %.3f]', P_cl), ...
%     'Interpreter', 'none');
% 
% figure('Name','State Feedback: stuurkracht','NumberTitle','off');
%     plot(t_sim, u_sim, 'LineWidth', 1.5); hold on;
%     % yline( F_max, 'r--', 'F_{max}');
%     % yline(-F_max, 'r--', 'F_{min}');
%     ylabel('F  (N)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
%     title('Stuurkracht  F'); grid on;
%% Mooiere plotjes

figure('Name','Staprespons State Feedback','NumberTitle','off');
subplot(3,1,1);
    plot(t_sim, x_sim(1,:), 'LineWidth', 1.5); hold on;
    yline(w_x, 'k--', 'DisplayName', 'Referentie');
    ylabel('x (m)'); title('Positie kar');
    legend('x', 'w_{ref}', 'Location', 'best'); grid on;

subplot(3,1,2);
    plot(t_sim, x_sim(3,:), 'LineWidth', 1.5, 'Color', [0.85 0.33 0.1]);
    ylabel('\theta (rad)'); title('Hoek pendulum');
    grid on;

subplot(3,1,3);
    plot(t_sim, u_sim, 'LineWidth', 1.5, 'Color', [0.2 0.7 0.2]);
    ylabel('F (N)'); xlabel('Tijd (s)');
    title('Stuurkracht'); grid on;

sgtitle(sprintf('State Feedback: polen [%.3f, %.3f, %.3f, %.3f], w=%.3f m', ...
    P_cl, w_x));

%% Performantie
if all(abs(x_sim(3,:)) < 0.5)   % theta bleef klein genoeg
    fprintf('Performantie (ideale simulatie):\n');
    % Insteltijd x: eerste tijdstip waarop |x - w_x| < 2% van beginafstand
    tol = 0.02 * abs(x0(1) - w_x);
    idx = find(abs(x_sim(1,:) - w_x) < tol, 1, 'first');
    if ~isempty(idx)
        fprintf('  Insteltijd x (2%%):  %.2f s\n', t_sim(idx));
    end
    fprintf('  Max |F|:           %.2f N\n', max(abs(u_sim)));
    fprintf('  Max |theta|:       %.4f rad\n\n', max(abs(x_sim(3,:))));
end

% =========================================================================
%% OPSLAAN NAAR JSON (voor Python StateFeedbackController)
% =========================================================================

fprintf('--- Parameters opslaan naar JSON ---\n');

esf_params = struct();
esf_params.controller_type = 'state_feedback';
esf_params.K    = K;
esf_params.Nbar = Nbar;
esf_params.Nx   = Nx';
esf_params.w    = w_x;

output_file = 'controller_params.json';
fid = fopen(output_file, 'w');
if fid == -1
    warning('Kon %s niet schrijven.', output_file);
else
    fwrite(fid, jsonencode(esf_params));
    fclose(fid);
    fprintf('  Opgeslagen in: %s\n', output_file);
end

fprintf('\n============================================================\n');
fprintf('  KLAAR — pas P_cl aan en herrun (Ctrl+Enter)\n');
fprintf('============================================================\n');
%% =========================================================================
%  VERGELIJKING: Python simulatie (CSV) vs Ideale MATLAB simulatie
% =========================================================================

fprintf('--- Vergelijking Python vs MATLAB ideale simulatie ---\n\n');

%% Laad CSV
try
    % data_meas = readmatrix(fullfile('Simulations Flament\Controller 3.0 (ExtStFb)\pendulum_measurements.csv'));
    data_meas = readmatrix(fullfile('pendulum_measurements.csv'));
catch
    data_meas = readmatrix('pendulum_states.csv');
end

x_py    = data_meas(:, 1);   % Kartpositie uit Python simulatie
phi_py  = data_meas(:, 2);   % Pendelhoek  uit Python simulatie
N_csv   = length(x_py);
t_csv   = (0:N_csv-1).' * Ts;

%% Plot 1 — Positie x: Python vs MATLAB
figure('Name', 'Vergelijking x: Python vs MATLAB', 'NumberTitle', 'off');

plot(t_csv,  x_py,           'r',  'LineWidth', 1.5, 'DisplayName', 'Python (CSV)');      hold on;
    plot(t_sim, x_sim(1,:),    'b--','LineWidth', 1.5, 'DisplayName', 'MATLAB (ideaal)');
    yline(w_x, 'k:', 'LineWidth', 1.2, 'DisplayName', sprintf('Setpoint w = %.2f m', w_x));
    ylabel('$x$ (m)', 'Interpreter', 'latex');
    xlabel('Tijd (s)', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    grid on;

sgtitle(sprintf('State feedback — Polen: [%.2f %.2f %.2f %.2f]', P_cl), ...
    'Interpreter', 'none');

%% Plot 2 — Hoek phi: Python vs MATLAB (bonus)
figure('Name', 'Vergelijking phi: Python vs MATLAB', 'NumberTitle', 'off');

plot(t_csv,  phi_py,         'r',  'LineWidth', 1.5, 'DisplayName', 'Python (CSV)');  hold on;
plot(t_sim, x_sim(3,:),    'b--','LineWidth', 1.5, 'DisplayName', 'MATLAB (ideaal)');
yline(0, 'k:', 'LineWidth', 1.0);
ylabel('$\theta$ (rad)', 'Interpreter', 'latex');
xlabel('Tijd (s)', 'Interpreter', 'latex');
title('Pendelhoek $\theta$: Python vs MATLAB (ideaal)', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;