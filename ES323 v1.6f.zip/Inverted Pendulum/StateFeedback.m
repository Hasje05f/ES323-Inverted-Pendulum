%% State Feedback Controller Design — Inverted Pendulum (discreet)
%
% Vereiste: voer eerst MATLAB_Code.m uit zodat de volgende variabelen
%           in de workspace aanwezig zijn:
%               sys_d   — discreet toestandsruimtemodel (ss-object)
%               A, B, C, D  — continue systeemmatrices
%               Ts      — bemonsteringstijd (0.05 s)
%
% Toestandsvector:  x = [x;  x_dot;  theta;  theta_dot]
% Ingang:           u = F (kracht op kar)
% Uitgang:          y = [x; theta]
%
% -------------------------------------------------------------------------
% THEORIE (zie slides ES322):
%
%   Toestandsterugkoppeling:  u[k] = -K * x[k]
%   Gesloten-lus:             x[k+1] = (A_d - B_d*K) * x[k]
%   Polen GL = eigenwaarden van A_d - B_d*K
%
%   Setpoint via variabelenwijziging (slide 13-15):
%     In stationaire toestand:  x_ss = A_d*x_ss + B_d*u_ss
%                               y_ss = C0*x_ss = w
%     Oplossing:  x_ss = Nx*w,  u_ss = Nu*w
%     Aansturing: u[k] = Nu*w - K*(x[k] - Nx*w)
%                       = (Nu + K*Nx)*w - K*x[k]
%
%   Met observer (scheidingsprincipe):
%     u[k] = (Nu + K*Nx)*w - K*x_hat[k]
%     De polen van het gecombineerd systeem zijn de unie van de
%     regelaar-polen (eig van A_d-B_d*K) en de observer-polen
%     (eig van A_d-L*C_d) — ze kunnen onafhankelijk ontworpen worden.
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  STATE FEEDBACK CONTROLLER DESIGN — discreet\n');
fprintf('  Ts = 0.05 s\n');
fprintf('============================================================\n\n');

%% Haal discrete systeemmatrices op
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;   % [1 0 0 0; 0 0 1 0]  — meet x en theta

% Voor setpoint: we regelen x (eerste uitgang)
% C0 = rij van C_d die overeenkomt met de te regelen uitgang y0 = x
C0 = C_d(1,:);   % [1 0 0 0]
B0 = B_d;        % enkele regelende ingang F

%% Controleer controleerbaarheid
Co = ctrb(A_d, B0);
fprintf('Rank controleerbaarheidsmatrix: %d (moet %d zijn)\n\n', ...
    rank(Co), size(A_d,1));

%% Open-lus polen (ter referentie)
p_ol = eig(A_d);
fprintf('Open-lus polen van A_d:\n');
for i = 1:length(p_ol)
    stabstr = '';
    if abs(p_ol(i)) > 1, stabstr = '  <-- INSTABIEL'; end
    fprintf('  p%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_ol(i)), imag(p_ol(i)), abs(p_ol(i)), stabstr);
end
fprintf('\n');

% =========================================================================
%% KEUZE VAN GESLOTEN-LUS POLEN
%
% Strategie:
%   - Alle 4 CL-polen moeten binnen de eenheidscirkel liggen (|p| < 1)
%   - De instabiele open-lus pool (|p| = 1.567) moet naar binnen gehaald worden
%   - Snellere polen (kleiner |p|) = snellere respons maar meer stuurkracht
%   - Begin met Polen geclusterd rond |z| = 0.3-0.6
%
%   Vergelijking met PID-gesloten-lus Polen (ter referentie):
%     PID had CL-Polen op: [1.00, 0.637, 0.376, 0.204, -0.078]
%     (5 Polen door 2de-orde regelaar + 3de-orde plant)
%     State feedback geeft exact 4 Polen — één per toestand.
%
% =========================================================================

% --- KIES HIER JE GESLOTEN-LUS POLEN ---
% P_cl = [0.8, 0.775, 0.75, 0.725];
P_cl = [0.7, 0.675, 0.65, 0.625];

%
% Tips:
%   * Reëel of complex-conjugaat paar
%   * Alle |p| < 1
%   * Vergroot absolute waarden voor tragere respons (minder F vereist)
%   * Verklein voor snellere respons (meer F vereist, mogelijk saturatie)
%   * Complex-conjugaat voorbeeld voor gedempte oscillatie:
%     P_cl = [0.5+0.2i, 0.5-0.2i, 0.3, 0.2];

%% Bereken winstmatrix K via place()
K = place(A_d, B_d, P_cl);

fprintf('Gewenste CL-Polen:\n');
for i = 1:length(P_cl)
    fprintf('  p_cl%d = %+.4f %+.4fi   |p| = %.4f\n', ...
        i, real(P_cl(i)), imag(P_cl(i)), abs(P_cl(i)));
end
fprintf('\n');

%% Verifieer eigenwaarden van (A_d - B_d*K)
A_cl = A_d - B_d * K;
p_cl_check = eig(A_cl);

fprintf('Winstmatrix K =\n');
disp(K);

fprintf('Verificatie eigenwaarden van (A_d - B_d*K):\n');
all_stable = true;
for i = 1:length(p_cl_check)
    stabstr = '';
    if abs(p_cl_check(i)) >= 1
        stabstr = '  <-- INSTABIEL!';
        all_stable = false;
    end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_cl_check(i)), imag(p_cl_check(i)), abs(p_cl_check(i)), stabstr);
end
fprintf('\n');

if ~all_stable
    fprintf('  [!] Systeem NIET stabiel — pas P_cl aan.\n\n');
    return;
end

% =========================================================================
%% SETPOINT VIA VARIABELENWIJZIGING (slides ES322, slide 13-15)
%
% We willen de kar naar positie w_x sturen terwijl theta -> 0.
% Te regelen uitgang: y0 = x  (eerste uitgang, C0 = [1 0 0 0])
%
% In stationaire toestand moet gelden:
%   x_ss = A_d * x_ss + B_d * u_ss   (toestandsvergelijking)
%   w_x  = C0  * x_ss                 (gewenste uitgang)
%
% Dit geeft het stelsel (slide 15):
%   [A_d - I,  B_d ] [Nx]   [0]
%   [C0,       0   ] [Nu] = [1]
%
% Oplossing: Nx (4x1) en Nu (scalar)
% Aansturing met setpoint: u = (Nu + K*Nx)*w_x - K*x_hat
%                            = Nbar * w_x - K * x_hat
% =========================================================================

fprintf('--- Setpoint berekening (Nx, Nu) ---\n\n');

% Stelsel opstellen
n  = size(A_d, 1);   % 4
Z  = [A_d - eye(n),  B_d;
      C0,            zeros(1, size(B_d,2))];
rhs = [zeros(n,1); 1];

% Oplossing
NxNu = Z \ rhs;
Nx = NxNu(1:n);        % 4x1 toestandsoffset per eenheid setpoint
Nu = NxNu(n+1:end);    % scalar ingangsoffset

Nbar = Nu + K * Nx;    % gecombineerde voorwaartse versterkingsfactor

fprintf('  Nx = [%.4f; %.4f; %.4f; %.4f]\n', Nx(1), Nx(2), Nx(3), Nx(4));
fprintf('  Nu = %.4f\n', Nu);
fprintf('  Nbar = Nu + K*Nx = %.4f\n\n', Nbar);
fprintf('  Aansturing: u[k] = Nbar * w_x - K * x_hat[k]\n\n');

% =========================================================================
%% SIMULATIE (zonder observer — ideaal geval: toestanden volledig gekend)
%
% We simuleren het gesloten-lus systeem met u = Nbar*w - K*x
% (alsof alle toestanden gemeten worden).
% Begintoestand: kar op x=-0.5 m, pendulum lichtjes schuin theta=0.05 rad.
% Setpoint: w_x = 0 (kar naar midden brengen).
%
% Later wordt dit vervangen door u = Nbar*w - K*x_hat (met observer).
% =========================================================================

fprintf('--- Simulatie (ideaal: alle toestanden gekend) ---\n\n');

w_x   = 0.0;                          % setpoint kartpositie [m]
x0    = [-0.5; 0; 0.05; 0];           % begintoestand
N_sim = 400;                           % tijdstappen
F_max = 9.0;                           % saturatie [N]

x_sim = zeros(4, N_sim);
u_sim = zeros(1, N_sim);
x_k   = x0;

for k = 1:N_sim
    x_sim(:, k) = x_k;

    % State feedback met setpoint
    u_k = Nbar * w_x - K * x_k;

    % Saturatie (simuleer max_F van Python-simulator)
    u_k = max(min(u_k, F_max), -F_max);
    u_sim(k) = u_k;

    % Systeem update (lineair model)
    x_k = A_d * x_k + B_d * u_k;
end

t_sim = (0:N_sim-1) * Ts;

%% PLOTS simulatie
figure('Name','State Feedback: toestandsrespons','NumberTitle','off');

subplot(2,2,1);
    plot(t_sim, x_sim(1,:), 'LineWidth', 1.5); hold on;
    yline(w_x, 'r--', 'Setpoint');
    ylabel('x  (m)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Positie  x', 'Interpreter', 'latex'); grid on;

subplot(2,2,2);
    plot(t_sim, x_sim(2,:), 'LineWidth', 1.5);
    ylabel('$\dot{x}$  (m/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Snelheid  $\dot{x}$', 'Interpreter', 'latex'); grid on;

subplot(2,2,3);
    plot(t_sim, x_sim(3,:), 'LineWidth', 1.5); hold on;
    % yline(0, 'r--', '\theta = 0');
    ylabel('$\theta$  (rad)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Hoek  $\theta$', 'Interpreter', 'latex'); grid on;

subplot(2,2,4);
    plot(t_sim, x_sim(4,:), 'LineWidth', 1.5);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Hoeksnelheid  $\dot{\theta}$', 'Interpreter', 'latex'); grid on;

sgtitle(sprintf('State Feedback — CL-Polen: [%.2f %.2f %.2f %.2f]', P_cl), ...
    'Interpreter', 'none');

figure('Name','State Feedback: stuurkracht','NumberTitle','off');
    plot(t_sim, u_sim, 'LineWidth', 1.5); hold on;
    % yline( F_max, 'r--', 'F_{max}');
    % yline(-F_max, 'r--', 'F_{min}');
    ylabel('F  (N)', 'Interpreter', 'latex'); xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Stuurkracht  F'); grid on;

%% Performantie
if all(abs(x_sim(3,:)) < 0.5)   % theta bleef klein genoeg
    fprintf('Performantie (ideale simulatie):\n');
    % Insteltijd x: eerste tijdstip waarop |x - w_x| < 2% van beginafstand
    tol = 0.02 * abs(x0(1) - w_x);
    idx = find(abs(x_sim(1,:) - w_x) < tol, 1, 'first');
    if ~isempty(idx)
        fprintf('  Insteltijd x (2%%):  %.2f s\n', t_sim(idx));
    end
    fprintf('  Max |F|:           %.2f N\n', max(abs(u_sim)));
    fprintf('  Max |theta|:       %.4f rad\n\n', max(abs(x_sim(3,:))));
end

% =========================================================================
%% OPSLAAN NAAR JSON (voor Python StateFeedbackController)
% =========================================================================

fprintf('--- Parameters opslaan naar JSON ---\n');

sf_params = struct();
sf_params.controller_type = 'state_feedback';
sf_params.K    = K;
sf_params.Nbar = Nbar;
sf_params.Nx   = Nx';
sf_params.w    = w_x;

output_file = 'controller_params.json';
fid = fopen(output_file, 'w');
if fid == -1
    warning('Kon %s niet schrijven.', output_file);
else
    fwrite(fid, jsonencode(sf_params));
    fclose(fid);
    fprintf('  Opgeslagen in: %s\n', output_file);
end

fprintf('\n============================================================\n');
fprintf('  KLAAR — pas P_cl aan en herrun (Ctrl+Enter)\n');
fprintf('  Volgende stap: koppel observer aan controller in Python\n');
fprintf('============================================================\n');