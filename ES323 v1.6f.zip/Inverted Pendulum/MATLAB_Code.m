%% Cart-Pendulum System - State Space Model & LQR Control
% Based on Lagrangian mechanics derivation
% System: Cart (M) with pendulum (m, length L) on rail of length d
%
% States:   x = [x; x_dot; theta; theta_dot]
% Input:    u = F (force on cart)
% Output:   y = [x; theta]

clear; clc; close all;
dir = "C:\Users\Flament.H\OneDrive - Belgian Defence\Academic - 178 POL - Personal\3 Ba\Sem. 2\ES323\simulators-master\Inverted Pendulum";
% dir = "C:\Users\bouba\OneDrive\Bureaublad\ES323 v1.2s\Simulations";

% Current Code Problems
% - M_opt and m_opt differ to greatly from what they should be and are not
% yet integrated in the state space model
% - Slight inconsistencies in nameginving etc
% - Directory inconsistencies when running 
% - Further additions?

%% Mathematical Model

% Lagrangian mechanics, Free Body Diagram on paper
syms t x(t) theta(t) 
syms l M m I g F b

x_p = x.*sin(theta);
y_p = l.*cos(theta);

x_pdot = diff(x_p,t,1);
y_pdot = l.*cos(theta);
v_p = sqrt(x_pdot.^2+y_pdot.^2);

% Kinetic Energy
T_cart = 0.5*M.*diff(x,t,1).^2;
T_pend_trans = 0.5.*m.*v_p.^2;
T_pend_rot = 0.5.*I.*diff(theta,t).^2;

T = T_cart + T_pend_trans + T_pend_rot;

% Potential Energy
V = m.*g.*y_p;

% Lagrangian
L = simplify(T - V);

% Euler-Lagrange  d/dt(∂L/∂q̇) - ∂L/∂q = Q_nc
    % Solving for x
    dL_dxdot  = diff(L, diff(x,t));
    ddt_xdot  = diff(dL_dxdot, t);
    dL_dx     = diff(L, x);
    
    eqn_x = F - b.*diff(x,t) == simplify(ddt_xdot - dL_dx);          
    
    % solving for theta
    dL_dthdot = diff(L, diff(theta,t));
    ddt_thdot = diff(dL_dthdot, t);
    dL_dth    = diff(L, theta);
    
    eqn_th = 0 == simplify(ddt_thdot - dL_dth);       

% Deliverables

disp('=== Equations of motion (from Euler-Lagrange, nonlineair) ===\n');
    disp('Equation for x (cart):');
    disp(eqn_x)
    disp('Equation for theta (pendulum):');
    disp(eqn_th)


%% Parameter Identification

% Directory of where all simulations are situated 
cd(dir + "\Simulations");

Ts = 0.05;
g_n = 9.81;


    %% EXPERIMENT 1 — Pendulum Natural Frequency (cart locked)

    data1_measerments = readmatrix('Parameter Experiment 1\pendulum_measurements.csv');

    phi_max = pi / 2.1;
    theta_sim = data1_measerments(:,2);

    n_sat1 = find(abs(theta_sim) >= phi_max - 1e-4, 1, 'first');
    if isempty(n_sat1)
        n_sat1 = length(theta_sim);
    end

    theta_sim_crop = theta_sim(1:n_sat1);
    t1             = (0:n_sat1-1) * Ts;

    syms theta(t) omega(t)
    eqs = [diff(theta,t) == omega;
           diff(omega,t) == (3/4)*(g/l)*theta];

    sol   = dsolve(eqs, [theta(0)==0.01, omega(0)==0]);
    theta = simplify(sol.theta);

    l_opt = fminbnd(@(l) theta_mse(l, t1, matlabFunction(theta), theta_sim_crop, g_n, phi_max), ...
                    0.05, 0.40);
    fprintf('=== Experiment 1 Results ===\n');
    fprintf('  Optimale lengte l = %.4f m\n', l_opt);

    theta_fun_opt   = matlabFunction(subs(theta, [g,l], [g_n, l_opt]));
    theta_model_opt = min(theta_fun_opt(t1), phi_max);

    l_extra = 0.15;
    theta_fun_extra = matlabFunction(subs(theta, [g,l], [g_n, l_extra]));
    theta_model_extra = min(theta_fun_extra(t1), phi_max);

    figure
        plot(t1,theta_sim_crop,'r--','LineWidth',1.5); hold on
        plot(t1,theta_model_opt,'LineWidth',1.5)
        plot(t1,theta_model_extra,'LineWidth',1.5)
        xlabel('Tijd (s)')
        xlim([0,2]);
        ylim([0,1.6]);
        ylabel('Hoek (rad)')
        title('Vergelijking Hoek \theta (Slinger) - Exp 1 - Bepaling l')
        legend('Python (Simulator)',sprintf('MatLab (optimale lengte l = %0.4f)',l_opt), 'MatLab (l = 0.15)','Location','best')
        grid on

    %% EXPERIMENT 2 — Pendulum at max angle, cart moves

    data2_states = readmatrix('Parameter Experiment 2\v2 F = 0.01\pendulum_states.csv');
    data2_inputs = readmatrix('Parameter Experiment 2\v2 F = 0.01\pendulum_inputs.csv');
                                      
    N2   = size(data2_states, 1);
    t2   = (0:N2-1) * Ts;                      
     
    x_sim2 = data2_states(:,1) - data2_states(1,1);
    F_exp2 = mean(data2_inputs(:,1));
    x_fun2 = @(t, M_plus_m, b, F) ...
        (F ./ b) .* t  -  (M_plus_m .* F ./ b.^2) .* (1 - exp(-b .* t ./ M_plus_m));
     
    x_max2 = 0.9;                              
    p0_exp2 = [0.7, 0.1];                       
     
    p_opt2 = fminsearch( ...
        @(p) x_mse(p, t2, x_fun2, x_sim2, x_max2, F_exp2), ...
        p0_exp2);
     
    M_plus_m_opt = p_opt2(1);
    b_opt      = p_opt2(2);
     
    fprintf('=== Experiment 2 Results ===\n');
    fprintf('  Optimale M+m = %.4f kg\n', M_plus_m_opt);
    fprintf('  Optimale b   = %.4f kg/s\n\n', b_opt);
      
    x_model2 = x_fun2(t2, M_plus_m_opt, b_opt, F_exp2);
    x_model2 = min(x_model2, x_max2);

    x_model_extra = x_fun2(t2, 0.7, 0.1, F_exp2);
    x_model_extra = min(x_model_extra, x_max2);
     
    figure
        plot(t2,x_sim2,'r--','LineWidth',1.5); hold on
        plot(t2,x_model2,'LineWidth',1.5)
        plot(t2,x_model_extra,'LineWidth',1.5)
        xlabel('Tijd (s)')
        ylabel('Positie x (m)')
        xlim([0,20]); ylim([-0.1 1]);
        title('Vergelijking positie x (kar) - Exp 2')
        legend(sprintf('Python (Measurements simulator)'),sprintf('MatLab (optimale fit: b = %0.4f, M+m = %0.4f)',b_opt, M_plus_m_opt),sprintf('MatLab (theoretisch: b=0.1, M+m=0.7)'),'Location','best')
        grid on

    %% EXPERIMENT 3 — Pendulum Natural Frequency (cart not locked)
    data3_states = readmatrix('Parameter Experiment 3\v2 add noise = false\pendulum_states.csv');
    data3_inputs = readmatrix('Parameter Experiment 3\v2 add noise = false\pendulum_inputs.csv');
     
    n_sat3 = find(abs(data3_states(:,3)) >= phi_max - 1e-4, 1, 'first');
    if isempty(n_sat3)
        n_sat3 = size(data3_states, 1);
    end

    N3 = n_sat3;
    t3 = (0:N3-1).' * Ts;
    x_sim3 = data3_states(1:N3,1) - data3_states(1,1);
    theta_sim3 = data3_states(1:N3,3);
    F_exp3 = mean(data2_inputs(:,1));

    x_fun3 = @(m) m.*l_opt.*sin(theta_sim3)./ (M_plus_m_opt);
    mse3 = @(m) mean((x_sim3 - x_fun3(m)).^2);

    m_opt = fminbnd(mse3, 0.01, M_plus_m_opt - 0.01);
    M_opt = M_plus_m_opt - m_opt;
    L_opt = 2 * l_opt;
    I_G_opt = m_opt.*L_opt^2./12;

        m_extra = 0.2;
        M_extra = 0.5;
        x_fun3_extra = m_extra .* l_opt .* sin(theta_sim3) ./ (M_extra + m_extra);

    fprintf('=== Experiment 3 Results ===\n');
    fprintf('  Optimal m = %.4f kg\n', m_opt);
    fprintf('  Optimal M = %.4f kg\n\n', M_opt);
    figure('Name', 'Vergelijking x (Kar) — Exp 3 — Bepaling m via impuls','NumberTitle', 'off');
        hold on;
        plot(t3, x_sim3,          '--', 'LineWidth', 1.5, 'DisplayName', 'Python (Simulator)');
        plot(t3, x_fun3(m_opt),         'LineWidth', 1.5, ...
            'DisplayName', sprintf('MATLAB (m=%.4f kg, M=%.4f kg)', m_opt, M_opt));
        plot(t3, x_fun3_extra, '-.', 'LineWidth', 1.5, ...
            'DisplayName', sprintf('MATLAB (m=%.2f kg, M=%.2f kg)', m_extra, M_extra));
        xlabel('Tijd (s)'); ylabel('Positie x (m)');
        legend('Location', 'best'); grid on;

     
    idx_end = min(16, numel(t3));    
    x_sim_short = x_sim3(1:idx_end);
    theta_sim_short = theta_sim3(1:idx_end);
    t_short = t3(1:idx_end);
    m_start = 0.3;

    mse_fun = @(m) mean(((m .* (x_sim_short - l_opt .* sin(theta_sim_short)) + (M_plus_m_opt - m) .* x_sim_short) / M_plus_m_opt - mean((m .* (x_sim_short - l_opt .* sin(theta_sim_short)) + (M_plus_m_opt - m) .* x_sim_short) / M_plus_m_opt)).^2);
    m_opt_local = fminsearch(mse_fun, m_start);
    M_opt_local = M_plus_m_opt - m_opt_local;
    I_G_opt_local = m_opt_local.*L_opt^2./12;

    x_pend_sim = x_sim_short - l_opt .* sin(theta_sim_short);
    x_com_opt = (m_opt_local .* x_pend_sim + M_opt_local .* x_sim_short) / M_plus_m_opt;
    

    figure('Name','Systeemposities en stationair zwaartepunt','NumberTitle','off');
        hold on;
        plot(t_short, x_sim_short, 'DisplayName', 'Positie kar (x)');
        plot(t_short, x_pend_sim, 'DisplayName', 'Positie pendulum (x_p)');
        plot(t_short, x_com_opt, 'DisplayName', 'Berekend zwaartepunt (CoM)');
        xlabel('Tijd (s)'); ylabel('Positie (m)');
        legend('show','Location','best'); grid on;

 
%% Summary

cd(dir) %return main folder
fprintf('==========================================================\n');
fprintf('  FINAL IDENTIFIED PARAMETERS\n');
fprintf('==========================================================\n');
fprintf('  l     = %.4f m\n',   l_opt);
fprintf('  L     = %.4f m\n',   2*l_opt);
fprintf('  M+m   = %.4f kg\n',  M_plus_m_opt);
fprintf('  b     = %.4f kg/s\n', b_opt);
fprintf('  m     = %.4f kg\n',  m_opt);
fprintf('  M     = %.4f kg\n',  M_opt);
fprintf('  m_local     = %.4f kg\n',  m_opt_local);
fprintf('  M_local     = %.4f kg\n',  M_opt_local);
fprintf('  I_G   = %.6f kg·m²\n', I_G_opt);
fprintf('  I_G_local   = %.6f kg·m²\n', I_G_opt_local);
fprintf('==========================================================\n');

%% PARAMETERS

% Clear workspace except keep L_opt and b_opt
 
clearvars -except L_opt b_opt M_opt m_opt I_G_opt x_max2 phi_max dir

L = L_opt;        % Pendulum total length [m]
l = L/2;          % Distance from pivot to pendulum CoM [m]
M = M_opt;        % Cart mass [kg]
m = m_opt;        % Pendulum mass [kg]
b = b_opt;        % Cart friction coefficient [kg/s]

g = 9.81;         % Gravitational acceleration [m/s^2]
c = 0.1;          % Cart length [m]
d = 2.0;          % Rail length [m] (x in [-1, 1])

% Moment of inertia of pendulum about its center of mass
I_G = I_G_opt;   % = 0.0015 kg·m²
Ts = 0.05;        % Sampling frequency [s]

%% STATE-SPACE MATRICES (around theta = 0)
%Soln by Lagrange mechanics (see

M_eq = (M + m) * (m*l^2 + I_G);
Delta = M_eq - m^2 * l^2;
fprintf('  Delta   = %.6f kg²·m²\n', Delta);
fprintf('==========================================================\n\n');


A = [ 0,                    1,                       0,  0 ;
      0,  -b*(m*l^2+I_G)/Delta,    g*m^2*l^2/Delta,          0 ;
      0,                    0,                       0,  1 ;
      0,      -b*m*l/Delta,         g*m*l*(M+m)/Delta,        0 ];

B = [ 0;
      (m*l^2 + I_G)/Delta;
      0;
      m*l/Delta ];

C = [ 1, 0, 0, 0 ;
      0, 0, 1, 0 ];

D = zeros(2, 1);

%% CONTROLLABILITY & OBSERVABILITY CHECK

Co = ctrb(A, B);
Ob = obsv(A, C);

    fprintf('=== System Analysis ===\n');
    fprintf('Rank of Controllability Matrix: %d (should be 4)\n', rank(Co));
    fprintf('Rank of Observability Matrix:   %d (should be 4)\n\n', rank(Ob));

%% State-Space Modeling

sys = ss(A,B,C,D,'InputName',{'F'},'OutputName',{'x','\theta'});
H = tf(sys); % Both for x and \theta respectivly
[p, z] = pzmap(sys(2,1));

    fprintf('=== State Space Continious ===\n');
    fprintf('H(2,1) transfer function:\n');
    tf(H(2,1))
    fprintf('poles: %s\n', mat2str(p.'));
    fprintf('zeros: %s\n', mat2str(z.'));

sys_d = c2d(sys, Ts);
H_d = tf(sys_d);
[p_d, z_d] = pzmap(sys_d(2,1));

    fprintf('=== State Space Discrete ===\n');
    fprintf('H_d(2,1) transfer function:\n');
    tf(H_d(2,1))
    fprintf('poles: %s\n', mat2str(p_d.'));
    fprintf('zeros: %s\n', mat2str(z_d.'));

%%
figure('Name','Continuous Step Response (all outputs)','NumberTitle','off');
    [y,tOut] = step(sys,10);
    x_step = min(y(:,1),x_max2); 
    theta_step = min(y(:,2),phi_max); 
    
    % Plot the step response for x and theta in a subplot
    subplot(2,1,1);
    plot(tOut, theta_step, 'b', 'LineWidth', 1.2); hold on;
    ylabel('\theta (rad)');
    title('Step Response: \theta');
    grid on;
    
    subplot(2,1,2);
    plot(tOut, x_step, 'r', 'LineWidth', 1.2); hold on;
    xlabel('Time (s)');
    ylabel('x (m)');
    title('Step Response: x');
    grid on;

figure('Name','Continuous Pole-Zero Map (theta output)','NumberTitle','off');
    pzmap(H(2,1));

sysd = c2d(sys, Ts); H_d = tf(sysd);

figure('Name','Discrete Step Response (all outputs)','NumberTitle','off');
   [yd,tOutd] = step(sysd,10);
    xd_step = min(yd(:,1),x_max2); 
    thetad_step = min(yd(:,2),phi_max); 
    
    % Plot the step response for x and theta in a subplot
    subplot(2,1,1);
    plot(tOutd, thetad_step, 'b', 'LineWidth', 1.2); hold on;
    ylabel('\theta (rad)');
    title('Step Response: \theta');
    grid on;
    
    subplot(2,1,2);
    plot(tOutd, xd_step, 'r', 'LineWidth', 1.2); hold on;
    xlabel('Time (s)');
    ylabel('x (m)');
    title('Step Response: x');
    grid on;

figure('Name','Discrete Pole-Zero Map (theta output)','NumberTitle','off');
    pzmap(H_d(2,1));


 cd(dir);
%% Additional functions for finding parameters
function mse = theta_mse(l,t,theta_fun,theta_sim,g, phi_max)
    theta_model = theta_fun(g,l,t);
    theta_model = min(theta_model,phi_max);
    mse = mean((theta_sim - theta_model').^2);
end

function mse = x_mse(p, t, x_fun, x_sim, x_max, F)
    M_plus_m = p(1);b = p(2);
    x_model = x_fun(t, M_plus_m, b, F);
    x_model = min(x_model,x_max);
    mse = mean((x_sim - x_model').^2);
end
