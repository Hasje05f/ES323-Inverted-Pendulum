%% ObserverOptESFBest.m
%
% PSO-gebaseerde optimalisatie van 4 observerpolen voor Extended State
% Feedback. Identiek aan ObserverOptSFBest.m maar de regelaar gebruikt
% K, Ki en een integratortoestand S_E — geen Nbar nodig.
%
% Vereist in workspace: sys_d, K, Ki (uit ExtendedStateFeedback.m)

clc; close all;

fprintf('==================================================\n');
fprintf('  OBSERVER OPTIMALISATIE — PSO (Extended SF)\n');
fprintf('==================================================\n\n');

%% Systeem
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;
Ts  = sys_d.Ts;

%% Parameters
N_sim   = 400;
N_mc    = 20;

F_max   = 9;
x0      = [0; 0; 0.05; 0];
w_ref   = 0.25;

sigma_x   = 0.01;
sigma_phi = 0.005;

lb        = 0.05 * ones(1,4);
ub        = 0.65 * ones(1,4);
delta_min = 0.005;

%% Open-lus Polen ter referentie
p_ol = eig(A_d);
fprintf('Open-lus Polen:\n');
for i = 1:4
    tag = '';
    if abs(p_ol(i)) > 1, tag = '  <-- instabiel'; end
    fprintf('  p%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_ol(i)), imag(p_ol(i)), abs(p_ol(i)), tag);
end
fprintf('\n');

%% Kostfunctie — geeft ESF-specifieke versie mee
cost = @(p) observer_cost_esf(p, A_d, B_d, C_d, K, Ki, w_ref, ...
    x0, N_sim, N_mc, F_max, sigma_x, sigma_phi, delta_min);

%% PSO
iter_log = [];

opts = optimoptions('particleswarm', ...
    'SwarmSize',          178, ...
    'MaxIterations',      178, ...
    'MaxStallIterations', 40,  ...
    'Display',            'iter', ...
    'UseParallel',        false, ...
    'OutputFcn', @(optimValues, state) pso_log(optimValues, state));

fprintf('PSO gestart — %d deeltjes, max 178 iteraties...\n\n', 178);
tic;
[p_best, J_best] = particleswarm(cost, 4, lb, ub, opts);
t_pso = toc;
fprintf('\nPSO klaar in %.1f s\n\n', t_pso);

%% Optimale Polen en observergain
P_obs = sort(p_best, 'descend');
L_opt = place(A_d', C_d', P_obs)';

fprintf('==================================================\n');
fprintf('  RESULTAAT\n');
fprintf('==================================================\n\n');
fprintf('P_obs = [%.4f  %.4f  %.4f  %.4f]\n\n', P_obs);
fprintf('J (positie-RMSE) = %.6f m\n\n', J_best);
fprintf('L_opt =\n'); disp(L_opt);

eigs_obs = eig(A_d - L_opt*C_d);
fprintf('Eigenwaarden (A_d - L*C_d):\n');
for i = 1:4
    tag = '';
    if abs(eigs_obs(i)) >= 1, tag = '  <-- INSTABIEL!'; end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(eigs_obs(i)), imag(eigs_obs(i)), abs(eigs_obs(i)), tag);
end
fprintf('\n');

%% Verificatiesimulatie (geen ruis, deterministisch)
xk   = x0;
xhk  = [x0(1); 0; x0(3); 0];
uk   = 0;
SE_k = 0;

x_hist  = zeros(4, N_sim);
xh_hist = zeros(4, N_sim);
u_hist  = zeros(1, N_sim);
SE_hist = zeros(1, N_sim);

for k = 1:N_sim
    x_hist(:,k)  = xk;
    xh_hist(:,k) = xhk;
    u_hist(k)    = uk;
    SE_hist(k)   = SE_k;

    yk   = C_d * xk;
    xhk  = A_d*xhk + B_d*uk + L_opt*(yk - C_d*xhk);

    % ESF: integrator op geschatte positie
    SE_k = SE_k + (xhk(1) - w_ref);
    uk   = min(max(-(K*xhk + Ki*SE_k), -F_max), F_max);

    xk = A_d*xk + B_d*uk;
end

t = (0:N_sim-1) * Ts;

% Performantie
tol = 0.02 * abs(w_ref - x0(1));
if tol < 1e-6, tol = 0.005; end
idx_settle = find(abs(x_hist(1,:) - w_ref) < tol, 1, 'first');
if ~isempty(idx_settle)
    fprintf('Insteltijd (2%%):  %.2f s\n', t(idx_settle));
else
    fprintf('Insteltijd (2%%):  niet bereikt\n');
end
fprintf('Statische fout:   %.6f m\n',   abs(x_hist(1,end) - w_ref));
fprintf('Max |F|:          %.2f N\n',   max(abs(u_hist)));
fprintf('Max |theta|:      %.4f rad\n\n', max(abs(x_hist(3,:))));

%% Schattingsfouten
e_v     = x_hist(2,:) - xh_hist(2,:);
e_omega = x_hist(4,:) - xh_hist(4,:);

%% ---- PLOTS ---------------------------------------------------------------

c1    = [0.13 0.47 0.71];
c2    = [0.84 0.15 0.16];
c3    = [0.17 0.63 0.17];
c_ref = [0.40 0.40 0.40];

%% Plot 1 — toestandsrespons
figure('Name','ESF Observer validatie — toestandsrespons','NumberTitle','off');
set(gcf, 'Position', [100 100 820 620]);

subplot(3,1,1);
    plot(t, x_hist(1,:),  'Color', c1, 'LineWidth', 1.8); hold on;
    plot(t, xh_hist(1,:), '--', 'Color', c2, 'LineWidth', 1.4);
    yline(w_ref, 'Color', c_ref, 'LineStyle', ':', 'LineWidth', 1.2);
    ylabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Positie kar', 'FontSize', 11, 'FontWeight', 'normal');
    legend('Werkelijk', 'Observer', 'Referentie', ...
        'Location', 'best', 'FontSize', 9, 'Box', 'off');
    set(gca, 'FontSize', 10); grid on; box off;

subplot(3,1,2);
    plot(t, x_hist(3,:),  'Color', [0.75 0.22 0.17], 'LineWidth', 1.8); hold on;
    plot(t, xh_hist(3,:), '--', 'Color', [0.98 0.55 0.38], 'LineWidth', 1.4);
    yline(0, 'Color', c_ref, 'LineStyle', ':', 'LineWidth', 1.2);
    ylabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Hoek pendulum', 'FontSize', 11, 'FontWeight', 'normal');
    legend('Werkelijk', 'Observer', 'Location', 'best', 'FontSize', 9, 'Box', 'off');
    set(gca, 'FontSize', 10); grid on; box off;

subplot(3,1,3);
    plot(t, u_hist, 'Color', c3, 'LineWidth', 1.8);
    yline( F_max, 'Color', [0.7 0.1 0.1], 'LineStyle', '--', 'LineWidth', 1.0, 'Label', 'F_{max}');
    yline(-F_max, 'Color', [0.7 0.1 0.1], 'LineStyle', '--', 'LineWidth', 1.0);
    ylabel('$F$ (N)', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Tijd (s)', 'FontSize', 11);
    title('Stuurkracht', 'FontSize', 11, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;

sgtitle(sprintf('ESF Observer validatie   $P = [%.3f,\\ %.3f,\\ %.3f,\\ %.3f]$', P_obs), ...
    'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'normal');

%% Plot 2 — integratortoestand
figure('Name','ESF Integratortoestand','NumberTitle','off');
set(gcf, 'Position', [100 100 820 280]);

plot(t, SE_hist, 'Color', [0.20 0.40 0.80], 'LineWidth', 1.8);
yline(0, 'Color', c_ref, 'LineStyle', ':', 'LineWidth', 1.0);
ylabel('$S_E = \sum(\hat{x} - w)$', 'Interpreter', 'latex', 'FontSize', 12);
xlabel('Tijd (s)', 'FontSize', 11);
title('Integratortoestand', 'FontSize', 11, 'FontWeight', 'normal');
set(gca, 'FontSize', 10); grid on; box off;

%% Plot 3 — schattingsfout niet-gemeten toestanden
figure('Name','ESF Schattingsfout','NumberTitle','off');
set(gcf, 'Position', [100 100 820 440]);

subplot(2,1,1);
    area(t, e_v, 'FaceColor', c1, 'FaceAlpha', 0.15, 'EdgeColor', c1, 'LineWidth', 1.5);
    yline(0, 'k--', 'LineWidth', 0.8);
    rms_v = sqrt(mean(e_v.^2));
    yline( rms_v, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    yline(-rms_v, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    ylabel('$\dot{x}$ (m/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('Schattingsfout snelheid   RMS $= %.4f$ m/s', rms_v), ...
        'Interpreter', 'latex', 'FontSize', 11, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;

subplot(2,1,2);
    area(t, e_omega, 'FaceColor', [0.75 0.22 0.17], 'FaceAlpha', 0.15, ...
        'EdgeColor', [0.75 0.22 0.17], 'LineWidth', 1.5);
    yline(0, 'k--', 'LineWidth', 0.8);
    rms_om = sqrt(mean(e_omega.^2));
    yline( rms_om, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    yline(-rms_om, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Tijd (s)', 'FontSize', 11);
    title(sprintf('Schattingsfout hoeksnelheid   RMS $= %.4f$ rad/s', rms_om), ...
        'Interpreter', 'latex', 'FontSize', 11, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;

sgtitle('Schattingsfout niet-gemeten toestanden $(e = x - \hat{x})$', ...
    'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'normal');

%% Plot 4 — PSO convergentie
if ~isempty(iter_log)
    figure('Name','PSO convergentie','NumberTitle','off');
    set(gcf, 'Position', [100 100 700 340]);

    semilogy(iter_log(:,1), iter_log(:,2), 'Color', c1, 'LineWidth', 1.8); hold on;
    scatter(iter_log(end,1), iter_log(end,2), 60, c2, 'filled');
    text(iter_log(end,1), iter_log(end,2)*1.3, ...
        sprintf('$J = %.5f$', iter_log(end,2)), ...
        'Interpreter', 'latex', 'FontSize', 10, 'HorizontalAlignment', 'right');
    xlabel('Iteratie', 'FontSize', 11);
    ylabel('Beste kost (log-schaal)', 'FontSize', 11);
    title('PSO convergentie', 'FontSize', 12, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;
end

%% Plot 5 — Polen in z-vlak
figure('Name','Polen in z-vlak','NumberTitle','off');
set(gcf, 'Position', [100 100 520 500]);

theta_c = linspace(0, 2*pi, 500);
plot(cos(theta_c), sin(theta_c), 'Color', [0.7 0.7 0.7], 'LineWidth', 1); hold on;
plot([-1.4 1.4], [0 0], 'Color', [0.88 0.88 0.88], 'LineWidth', 0.6);
plot([0 0], [-1.4 1.4], 'Color', [0.88 0.88 0.88], 'LineWidth', 0.6);

scatter(real(eig(A_d)),       imag(eig(A_d)),       90, c2, 's', 'filled', 'DisplayName', 'Open-lus');
scatter(real(eig(A_d-B_d*K)), imag(eig(A_d-B_d*K)), 90, c1, '^', 'filled', 'DisplayName', 'Regelaar CL');
scatter(real(eigs_obs),       imag(eigs_obs),        90, c3, 'o', 'filled', 'DisplayName', 'Observer');

axis equal; xlim([-1.6 1.6]); ylim([-1.3 1.3]);
xlabel('$\mathrm{Re}(z)$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$\mathrm{Im}(z)$', 'Interpreter', 'latex', 'FontSize', 12);
title('Polen in het $z$-vlak', 'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'normal');
legend('Location', 'northwest', 'FontSize', 9, 'Box', 'off');
set(gca, 'FontSize', 10); grid on; box off;

%% Opslaan naar JSON
obs.A  = A_d;
obs.B  = B_d;
obs.C  = C_d;
obs.L  = L_opt;
obs.P  = P_obs;
obs.Ts = Ts;

fid = fopen('observer_params.json', 'w');
if fid ~= -1
    fwrite(fid, jsonencode(obs));
    fclose(fid);
    fprintf('observer_params.json opgeslagen.\n');
end

fprintf('\nP_obs = [%.4f  %.4f  %.4f  %.4f];\n', P_obs);
fprintf('\n==================================================\n');
fprintf('  KLAAR\n');
fprintf('==================================================\n');

%% =========================================================================
%% Lokale functies
%% =========================================================================

function stop = pso_log(optimValues, ~)
    stop = false;
    assignin('base', 'iter_log', ...
        [evalin('base','iter_log'); optimValues.iteration, optimValues.bestfval]);
end

function J = observer_cost_esf(p, A_d, B_d, C_d, K, Ki, w_ref, ...
        x0, N_sim, N_mc, F_max, sigma_x, sigma_phi, delta_min)

    if any(abs(p) >= 1)
        J = 1e6; return;
    end

    pairs = nchoosek(1:4, 2);
    for i = 1:size(pairs,1)
        if abs(p(pairs(i,1)) - p(pairs(i,2))) < delta_min
            J = 1e6; return;
        end
    end

    try
        L = place(A_d', C_d', p)';
    catch
        J = 1e6; return;
    end

    if any(abs(eig(A_d - L*C_d)) >= 1)
        J = 1e6; return;
    end

    J_mc = zeros(N_mc, 1);

    for mc = 1:N_mc
        rng(mc);

        xk   = x0;
        xhk  = [x0(1); 0; x0(3); 0];
        uk   = 0;
        SE_k = 0;
        ex   = zeros(N_sim, 1);

        for k = 1:N_sim
            % Meting met ruis
            yk  = C_d*xk + [sigma_x; sigma_phi] .* randn(2,1);

            % Observer
            xhk = A_d*xhk + B_d*uk + L*(yk - C_d*xhk);

            % Integrator op geschatte positie (zoals in Python)
            SE_k = SE_k + (xhk(1) - w_ref);

            % ESF regelaar
            uk = min(max(-(K*xhk + Ki*SE_k), -F_max), F_max);

            % Positiefout
            ex(k) = xk(1) - w_ref;

            % Plant
            xk = A_d*xk + B_d*uk;

            if any(abs(xk) > 1e3)
                J_mc(mc) = 1e6; break;
            end
        end

        if J_mc(mc) < 1e5
            J_mc(mc) = sqrt(mean(ex.^2));
        end
    end

    J = mean(J_mc);
end

%% Resultaten eenmaal de code te laten lopen:
% ==================================================
%   OBSERVER OPTIMALISATIE — PSO (Extended SF)
% ==================================================
% 
% Open-lus Polen:
%   p1 = +1.0000 +0.0000i   |p| = 1.0000
%   p2 = +1.5671 +0.0000i   |p| = 1.5671  <-- instabiel
%   p3 = +0.9929 +0.0000i   |p| = 0.9929
%   p4 = +0.6366 +0.0000i   |p| = 0.6366
% 
% PSO gestart — 178 deeltjes, max 178 iteraties...
% 
% 
%                                  Best            Mean     Stall
% Iteration     f-count            f(x)            f(x)    Iterations
%     0             178          0.0664       7.303e+04        0
%     1             356         0.06638       6.011e+05        0
%     2             534         0.06638        1.91e+05        1
%     3             712         0.06636       3.177e+05        0
%     4             890         0.06636        1.91e+05        1
%     5            1068         0.06636       2.596e+05        2
%     6            1246         0.06636        2.36e+05        3
%     7            1424         0.06636        2.64e+05        4
%     8            1602         0.06636        3.09e+05        5
%     9            1780         0.06636       1.758e+05        6
%    10            1958         0.06636       1.067e+05        7
%    11            2136         0.06634       7.865e+04        0
%    12            2314         0.06634       1.461e+05        1
%    13            2492         0.06632       1.067e+05        0
%    14            2670         0.06632       8.427e+04        1
%    15            2848         0.06631       7.865e+04        0
%    16            3026         0.06631       1.124e+05        0
%    17            3204         0.06631       8.989e+04        1
%    18            3382         0.06631       7.303e+04        0
%    19            3560         0.06631       7.865e+04        0
%    20            3738         0.06631        6.18e+04        1
%    21            3916         0.06631       5.056e+04        0
%    22            4094         0.06631       1.011e+05        1
%    23            4272         0.06631        6.18e+04        0
%    24            4450         0.06631       6.742e+04        0
%    25            4628         0.06631       5.618e+04        0
%    26            4806         0.06631       7.303e+04        0
%    27            4984         0.06631       5.056e+04        1
%    28            5162         0.06631       8.427e+04        2
%    29            5340         0.06631       3.371e+04        3
%    30            5518         0.06631       8.989e+04        4
% 
%                                  Best            Mean     Stall
% Iteration     f-count            f(x)            f(x)    Iterations
%    31            5696         0.06631       2.247e+04        5
%    32            5874         0.06631       4.494e+04        0
%    33            6052         0.06631       2.247e+04        1
%    34            6230         0.06631       4.494e+04        0
%    35            6408         0.06631       2.247e+04        0
%    36            6586         0.06631       3.371e+04        0
%    37            6764         0.06631       3.933e+04        0
%    38            6942         0.06631       5.056e+04        1
%    39            7120         0.06631       2.247e+04        2
%    40            7298         0.06631       4.494e+04        3
%    41            7476         0.06631       3.933e+04        4
%    42            7654         0.06631       3.371e+04        0
%    43            7832         0.06631       2.809e+04        1
%    44            8010         0.06631       2.809e+04        0
%    45            8188         0.06631       3.933e+04        1
%    46            8366         0.06631            5618        0
%    47            8544         0.06631       4.494e+04        0
%    48            8722         0.06631       1.685e+04        1
%    49            8900         0.06631       2.809e+04        2
%    50            9078         0.06631       3.933e+04        0
%    51            9256         0.06631       1.685e+04        0
%    52            9434         0.06631       3.371e+04        1
%    53            9612         0.06631       1.685e+04        2
%    54            9790         0.06631       4.494e+04        3
%    55            9968         0.06631        6.18e+04        0
%    56           10146         0.06631       2.809e+04        1
%    57           10324         0.06631       2.247e+04        2
% Optimization ended: relative change in the objective value 
% over the last OPTIONS.MaxStallIterations iterations is less than OPTIONS.FunctionTolerance.
% 
% PSO klaar in 333.9 s
% 
% ==================================================
%   RESULTAAT
% ==================================================
% 
% P_obs = [0.6491  0.4157  0.3427  0.2356]
% 
% J (positie-RMSE) = 0.066307 m
% 
% L_opt =
%     1.1227    0.1434
%     6.0094    1.9584
%     0.1395    1.4308
%     1.6061   13.8459
% 
% Eigenwaarden (A_d - L*C_d):
%   eig1 = +0.6491 +0.0000i   |p| = 0.6491
%   eig2 = +0.2356 +0.0000i   |p| = 0.2356
%   eig3 = +0.4157 +0.0000i   |p| = 0.4157
%   eig4 = +0.3427 +0.0000i   |p| = 0.3427
% 
% Insteltijd (2%):  2.00 s
% Statische fout:   0.000065 m
% Max |F|:          1.40 N
% Max |theta|:      0.0500 rad
% 
% observer_params.json opgeslagen.
% 
% P_obs = [0.6491  0.4157  0.3427  0.2356];
% 
% ==================================================
%   KLAAR
% ==================================================
