%% Extended State Feedback Controller Design — Inverted Pendulum (discreet)
%
% Vereiste: voer eerst MATLAB_Code.m uit zodat sys_d en Ts in de workspace
%           aanwezig zijn.
%
% Toestandsvector origineel:  x  = [x; x_dot; theta; theta_dot]
% Uitgebreide toestandsvector: xE = [x; x_dot; theta; theta_dot; S_E]
%   waarbij S_E[k+1] = S_E[k] + (y0[k] - w) = S_E[k] + (x[k] - w)
%
% -------------------------------------------------------------------------
% THEORIE (zie slides ES322, slide 16-19):
%
%   Uitgebreide systeemmatrices:
%     A_E = [A_d,   0  ]     B_E = [B_d]
%           [C0,    1  ]            [0  ]
%
%   Uitgebreide toestandsterugkoppeling:
%     u[k] = -K_E * xE[k] = -K * x[k] - Ki * S_E[k]
%
%   De integrator garandeert nul statische fout:
%     zolang x != w groeit S_E -> Ki*S_E duwt u tot de fout nul is
%     geen Nbar/Nx nodig: de integrator regelt het setpoint zelf
%
%   5 gesloten-lus polen kiezen (4 voor dynamica + 1 voor integrator)
%   Integratorp ol typisch iets trager dan de snelste regelaarpool
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  EXTENDED STATE FEEDBACK — discreet\n');
fprintf('  Ts = 0.05 s\n');
fprintf('============================================================\n\n');

%% Systeemmatrices
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;
C0  = C_d(1,:);   % [1 0 0 0] — te regelen uitgang = x

n = size(A_d,1);  % 4

%% Uitgebreide matrices (slide 17)
%   A_E = [A_d,  zeros(n,1)]     B_E = [B_d  ]
%         [C0,   1          ]           [  0  ]
A_E = [A_d,        zeros(n,1);
       C0,          1         ];

B_E = [B_d; 0];

fprintf('Uitgebreide systeemmatrices:\n');
fprintf('  A_E (%dx%d), B_E (%dx1)\n\n', size(A_E,1), size(A_E,2), size(B_E,1));

%% Controleerbaarheid uitgebreid systeem
Co_E = ctrb(A_E, B_E);
fprintf('Rank controleerbaarheid (uitgebreid): %d (moet %d zijn)\n\n', ...
    rank(Co_E), size(A_E,1));

%% Open-lus polen uitgebreid systeem (ter referentie)
p_E = eig(A_E);
fprintf('Open-lus polen A_E:\n');
for i = 1:length(p_E)
    stabstr = '';
    if abs(p_E(i)) > 1, stabstr = '  <-- INSTABIEL'; end
    fprintf('  p%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_E(i)), imag(p_E(i)), abs(p_E(i)), stabstr);
end
fprintf('\n');
% Merk op: de uitgebreide A_E heeft een extra pool op z=1 (de integrator)

% =========================================================================
%% KEUZE VAN 5 GESLOTEN-LUS POLEN
%
% Je plaatst nu 5 polen: 4 voor de dynamica (zelfde redenering als
% gewone state feedback) + 1 voor de integratortoestand S_E.
%
% Richtlijn voor de integratorp ol:
%   - Trager dan de andere polen (grotere |z|) zodat de integrator
%     niet domineert maar wel de statische fout wegwerkt
%   - Te snel (kleine |z|): integrator reageert agressief, overshoot
%   - Te traag (|z| dicht bij 1): integrator werkt maar convergeert traag
%   - Typisch: integratorp ol op |z| = 0.7-0.85
%
% =========================================================================

% --- KIES HIER JE 5 POLEN ---

% P_E =   [0.95, 0.90, 0.85, 0.80, 0.75];                  
% P_E = [0.95, 0.94, 0.93, 0.92,    0.97];
% P_E = [0.85, 0.825, 0.8, 0.775,   0.99];
% P_E = [0.91, 0.90, 0.89, 0.88,  0.87];
% P_E = [0.88, 0.87, 0.86, 0.85,  0.84];
% P_E = [0.86, 0.85, 0.84, 0.83,  0.82];
% P_E = [0.85, 0.84, 0.83, 0.82,  0.81];
% P_E = [0.85, 0.84, 0.83, 0.82,  0.975];       %Beste Extended State feedback om een of andere reden
% P_E = [0.60 0.63 0.83 0.84 0.85];
% P_E = [0.84, 0.83, 0.82, 0.81,  0.80];
% P_E = [0.82 0.79 0.76 0.73 0.9];
P_E = [0.85 0.81 0.76 0.73 0.92];
% P_E = [0.80, 0.79, 0.78, 0.77, 0.76];
% P_E = [0.75, 0.74, 0.73, 0.72, 0.71];
% P_E = [0.80, 0.79, 0.78, 0.77,   0.975];
% P_E = [0.69, 0.68, 0.67, 0.66, 0.65];
% P_E = [0.63, 0.62, 0.61, 0.60, 0.64];
% P_E = [0.60, 0.59, 0.58, 0.57, 0.98];
% P_E = [0.4, 0.39, 0.38, 0.37, 0.36];


%      |--- 4 dynamische polen ---|  |-- integratorp ol --|

%% Bereken uitgebreide winstmatrix K_E via place()
K_E = place(A_E, B_E, P_E);

% Ontbinding: K_E = [K, Ki]  (slide 18)
K  = K_E(1:n);      % 1x4 toestandsterugkoppeling
Ki = K_E(n+1);      % scalar integratieve winst

fprintf('Gewenste CL-Polen (uitgebreid systeem):\n');
for i = 1:length(P_E)
    if i == 5
        fprintf('  p_E%d = %+.4f %+.4fi   |p| = %.4f  <-- integratorp ol\n', ...
            i, real(P_E(i)), imag(P_E(i)), abs(P_E(i)));
    else
        fprintf('  p_E%d = %+.4f %+.4fi   |p| = %.4f\n', ...
            i, real(P_E(i)), imag(P_E(i)), abs(P_E(i)));
    end
end
fprintf('\n');

fprintf('Uitgebreide winstmatrix K_E =\n');
disp(K_E);
fprintf('  K  = [%.4f  %.4f  %.4f  %.4f]\n', K(1), K(2), K(3), K(4));
fprintf('  Ki = %.4f\n\n', Ki);

%% Verificatie
A_cl_E = A_E - B_E * K_E;
p_cl_E = eig(A_cl_E);

fprintf('Verificatie eigenwaarden (A_E - B_E*K_E):\n');
all_stable = true;
for i = 1:length(p_cl_E)
    stabstr = '';
    if abs(p_cl_E(i)) > 1
        stabstr = '  <-- INSTABIEL!';
        all_stable = false;
    end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_cl_E(i)), imag(p_cl_E(i)), abs(p_cl_E(i)), stabstr);
end
fprintf('\n');

if ~all_stable
    fprintf('  [!] Systeem NIET stabiel — pas P_E aan.\n\n');
    return;
end

% =========================================================================
%% SIMULATIE (ideaal: alle toestanden gekend)
%
% De uitgebreide aansturing is:
%   u[k] = -K*x[k] - Ki*S_E[k]
%
% S_E wordt elke stap bijgewerkt:
%   S_E[k+1] = S_E[k] + (x[k] - w_x)
%
% Geen Nbar/Nx nodig: de integrator zorgt zelf dat x -> w_x.
% =========================================================================

fprintf('--- Simulatie (ideaal: alle toestanden gekend) ---\n\n');

w_x   = 0.25;                  % setpoint kartpositie [m] — probeer ook 0, -0.25, ...
x0    = [-0; 0; 0.05; 0];   % begintoestand  %-0.25
N_sim = 400;
F_max = 9.0;

x_sim  = zeros(4, N_sim);
u_sim  = zeros(1, N_sim);
SE_sim = zeros(1, N_sim);

x_k  = x0;
SE_k = 0;   % integratortoestand start op 0

for k = 1:N_sim
    x_sim(:,k)  = x_k;
    SE_sim(k)   = SE_k;

    % Uitgebreide toestandsterugkoppeling
    u_k = -(K * x_k + Ki * SE_k);
    u_k = max(min(u_k, F_max), -F_max);
    u_sim(k) = u_k;

    % Systeemupdate (lineair model)
    x_k  = A_d * x_k + B_d * u_k;

    % Integrator update: S_E[k+1] = S_E[k] + (y0[k] - w)
    %                              = S_E[k] + (x[k] - w_x)
    SE_k = SE_k + (x_sim(1,k) - w_x);
end

t_sim = (0:N_sim-1) * Ts;

%% Plots
figure('Name','Extended SF: toestandsrespons','NumberTitle','off');

subplot(2,2,1);
    plot(t_sim, x_sim(1,:), 'LineWidth', 1.5); hold on;
    yline(w_x, 'r--', 'DisplayName', 'Setpoint');
    ylabel('x  (m)', 'Interpreter', 'latex');
    xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Positie  $x$', 'Interpreter', 'latex');
    legend('Location','best'); grid on;

subplot(2,2,2);
    plot(t_sim, x_sim(2,:), 'LineWidth', 1.5);
    ylabel('$\dot{x}$  (m/s)', 'Interpreter', 'latex');
    xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Snelheid  $\dot{x}$', 'Interpreter', 'latex'); grid on;

subplot(2,2,3);
    plot(t_sim, x_sim(3,:), 'LineWidth', 1.5);
    ylabel('$\theta$  (rad)', 'Interpreter', 'latex');
    xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Hoek  $\theta$', 'Interpreter', 'latex'); grid on;

subplot(2,2,4);
    plot(t_sim, x_sim(4,:), 'LineWidth', 1.5);
    ylabel('$\dot{\theta}$  (rad/s)', 'Interpreter', 'latex');
    xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Hoeksnelheid  $\dot{\theta}$', 'Interpreter', 'latex'); grid on;

sgtitle(sprintf('Extended SF — Polen: [%.3f %.3f %.3f %.3f | %.3f]', P_E), ...
    'Interpreter', 'none');

figure('Name','Extended SF: stuurkracht en integrator','NumberTitle','off');

subplot(2,1,1);
    plot(t_sim, u_sim, 'LineWidth', 1.5, 'Color', [0.2 0.7 0.2]); hold on;
    ylabel('F  (N)'); xlabel('Tijd (s)');
    title('Stuurkracht  F'); grid on;

subplot(2,1,2);
    plot(t_sim, SE_sim, 'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
    ylabel('$S_E$', 'Interpreter', 'latex'); xlabel('Tijd (s)');
    title('Integratortoestand  $S_E = \sum(x - w)$', 'Interpreter', 'latex');
    grid on;

sgtitle(sprintf('Extended SF: Ki=%.4f, w=%.2f m', Ki, w_x), 'Interpreter', 'none');

%% Performantie
if all(abs(x_sim(3,:)) < 0.5)
    fprintf('Performantie (ideale simulatie, w=%.2f m):\n', w_x);
    tol = 0.02 * max(abs(x0(1) - w_x), 0.01);
    idx = find(abs(x_sim(1,:) - w_x) < tol, 1, 'first');
    if ~isempty(idx)
        fprintf('  Insteltijd x (2%%):  %.2f s\n', t_sim(idx));
    else
        fprintf('  Insteltijd x (2%%):  niet bereikt binnen simulatie\n');
    end
    fprintf('  Statische fout x:   %.6f m\n', abs(x_sim(1,end) - w_x));
    fprintf('  Max |F|:            %.2f N\n', max(abs(u_sim)));
    fprintf('  Max |theta|:        %.4f rad\n\n', max(abs(x_sim(3,:))));
end

% =========================================================================
%% OPSLAAN NAAR JSON
% =========================================================================

fprintf('--- Parameters opslaan naar JSON ---\n');

esf_params            = struct();
esf_params.controller_type = 'extended_sf';
esf_params.K          = K;
esf_params.Ki         = Ki;
esf_params.w          = w_x;

output_file = 'controller_params.json';
fid = fopen(output_file, 'w');
if fid == -1
    warning('Kon %s niet schrijven.', output_file);
else
    fwrite(fid, jsonencode(esf_params));
    fclose(fid);
    fprintf('  Opgeslagen in: %s\n', output_file);
end

fprintf('\n============================================================\n');
fprintf('  KLAAR — pas P_E (5 polen) en w_x aan en herrun\n');
fprintf('============================================================\n');

%% =========================================================================
%  VERGELIJKING: Python simulatie (CSV) vs Ideale MATLAB simulatie
% =========================================================================

fprintf('--- Vergelijking Python vs MATLAB ideale simulatie ---\n\n');

try
    %% Laad CSV
    data_meas = readmatrix('pendulum_measurements.csv');

    x_py    = data_meas(:, 1);   % Kartpositie uit Python simulatie
    phi_py  = data_meas(:, 2);   % Pendelhoek  uit Python simulatie
    N_csv   = length(x_py);
    t_csv   = (0:N_csv-1).' * Ts;
    
    %% Plot 1 — Positie x: Python vs MATLAB
    figure('Name', 'Vergelijking x: Python vs MATLAB', 'NumberTitle', 'off');
    
    plot(t_csv,  x_py,           'r',  'LineWidth', 1.5, 'DisplayName', 'Python (CSV)');      hold on;
        plot(t_sim, x_sim(1,:),    'b--','LineWidth', 1.5, 'DisplayName', 'MATLAB (ideaal)');
        yline(w_x, 'k:', 'LineWidth', 1.2, 'DisplayName', sprintf('Setpoint w = %.2f m', w_x));
        ylabel('$x$ (m)', 'Interpreter', 'latex');
        xlabel('Tijd (s)', 'Interpreter', 'latex');
        legend('Location', 'best', 'Interpreter', 'latex');
        grid on;
    
    sgtitle(sprintf('Extended SF — Polen: [%.2f %.2f %.2f %.2f | %.3f]', P_E), ...
        'Interpreter', 'none');
    
    %% Plot 2 — Hoek phi: Python vs MATLAB (bonus)
    figure('Name', 'Vergelijking phi: Python vs MATLAB', 'NumberTitle', 'off');
    
    plot(t_csv,  phi_py,         'r',  'LineWidth', 1.5, 'DisplayName', 'Python (CSV)');  hold on;
    plot(t_sim, x_sim(3,:),    'b--','LineWidth', 1.5, 'DisplayName', 'MATLAB (ideaal)');
    yline(0, 'k:', 'LineWidth', 1.0);
    ylabel('$\theta$ (rad)', 'Interpreter', 'latex');
    xlabel('Tijd (s)', 'Interpreter', 'latex');
    title('Pendelhoek $\theta$: Python vs MATLAB (ideaal)', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    grid on;
catch
    warning("First run PENDULUM.PY to get validation on simulated data")    
end