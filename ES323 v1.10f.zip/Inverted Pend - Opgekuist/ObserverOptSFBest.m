%% ObserverOptSFBest.m
%
% Dit script optimaliseert de 4 polen van een toestandsobserver met behulp
% van Particle Swarm Optimization (PSO).
%
% De kostfunctie is de gemiddelde positie-RMSE, berekend via meerdere
% Monte Carlo simulaties met meetruis. Voor elke kandidaat set polen wordt:
%   - een observergain L bepaald via pole placement
%   - een gesloten-lus simulatie uitgevoerd (met regelaar en saturatie)
%   - de prestaties geëvalueerd op basis van trackingfout
%
% Na optimalisatie:
%   - worden de optimale observerpolen en bijhorende L berekend
%   - wordt een verificatiesimulatie uitgevoerd (zonder ruis)
%   - worden prestaties en grafieken getoond (toestanden, fout, PSO-convergentie, polen)
%   - worden de observerparameters opgeslagen in een JSON-bestand
%
% Vereist in workspace: sys_d (discreet systeem), K (regelaar), Nbar (feedforward)


clc; close all;

fprintf('==================================================\n');
fprintf('  OBSERVER POOL OPTIMALISATIE — PSO\n');
fprintf('==================================================\n\n');

%% Systeem
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;
Ts  = sys_d.Ts;

%% Parameters
N_sim   = 400;          % simulatiestappen per evaluatie
N_mc    = 20;           % Monte Carlo runs per kandidaat

F_max   = 9;            % saturatie regelaar [N]
x0      = [0;0;0.05;0]; % begintoestand plant
w_ref   = 0.25;         % positie-setpoint [m]

sigma_x   = 0.01;       % meetruis standaardafwijking positie
sigma_phi = 0.005;      % meetruis standaardafwijking hoek

lb        = 0.05 * ones(1,4);   % ondergrens Polen
ub        = 0.65 * ones(1,4);   % bovengrens Polen
delta_min = 0.005;               % minimale afstand tussen Polen

%% Open-lus Polen ter referentie
p_ol = eig(A_d);
fprintf('Open-lus Polen:\n');
for i = 1:4
    tag = '';
    if abs(p_ol(i)) > 1, tag = '  <-- instabiel'; end
    fprintf('  p%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_ol(i)), imag(p_ol(i)), abs(p_ol(i)), tag);
end
fprintf('\n');

%% Kostfunctie
cost = @(p) observer_cost(p, A_d, B_d, C_d, K, Nbar, w_ref, ...
    x0, N_sim, N_mc, F_max, sigma_x, sigma_phi, delta_min);

%% PSO — iteratiehistorie bijhouden via OutputFcn
iter_log = [];   % [iteratie, beste_kost]

opts = optimoptions('particleswarm', ...
    'SwarmSize',         178, ...
    'MaxIterations',     178, ...
    'MaxStallIterations',40, ...
    'Display',           'iter', ...
    'UseParallel',       false, ...
    'OutputFcn', @(optimValues, state) pso_log(optimValues, state));

fprintf('PSO gestart — %d deeltjes, max 178 iteraties...\n\n', 178);
tic;
[p_best, J_best] = particleswarm(cost, 4, lb, ub, opts);
t_pso = toc;

fprintf('\nPSO klaar in %.1f s\n\n', t_pso);

%% Optimale Polen sorteren en L berekenen
P_obs = sort(p_best, 'descend');
L_opt = place(A_d', C_d', P_obs)';

fprintf('==================================================\n');
fprintf('  RESULTAAT\n');
fprintf('==================================================\n\n');
fprintf('P_obs = [%.4f  %.4f  %.4f  %.4f]\n\n', P_obs);
fprintf('J (positie-RMSE) = %.6f m\n\n', J_best);
fprintf('L_opt =\n'); disp(L_opt);

% Eigenwaarden observer verificeren
eigs_obs = eig(A_d - L_opt*C_d);
fprintf('Eigenwaarden (A_d - L*C_d):\n');
for i = 1:4
    tag = '';
    if abs(eigs_obs(i)) >= 1, tag = '  <-- INSTABIEL!'; end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(eigs_obs(i)), imag(eigs_obs(i)), abs(eigs_obs(i)), tag);
end
fprintf('\n');

%% Verificatiesimulatie (geen ruis, deterministisch)
xk  = x0;
xhk = [x0(1); 0; x0(3); 0];
uk  = 0;

x_hist  = zeros(4, N_sim);
xh_hist = zeros(4, N_sim);
u_hist  = zeros(1, N_sim);

for k = 1:N_sim
    x_hist(:,k)  = xk;
    xh_hist(:,k) = xhk;
    u_hist(k)    = uk;

    yk  = C_d * xk;
    xhk = A_d*xhk + B_d*uk + L_opt*(yk - C_d*xhk);
    uk  = min(max(Nbar*w_ref - K*xhk, -F_max), F_max);
    xk  = A_d*xk + B_d*uk;
end

t = (0:N_sim-1) * Ts;

% Insteltijd (2% band)
tol = 0.02 * abs(w_ref - x0(1));
idx_settle = find(abs(x_hist(1,:) - w_ref) < tol, 1, 'first');
if ~isempty(idx_settle)
    fprintf('Insteltijd (2%%):  %.2f s\n',   t(idx_settle));
end
fprintf('Max |F|:          %.2f N\n',   max(abs(u_hist)));
fprintf('Max |theta|:      %.4f rad\n', max(abs(x_hist(3,:))));
fprintf('Eind positie:     %.4f m\n\n', x_hist(1,end));

%% Plot 1 — toestandsrespons
figure('Name','Verificatie — toestandsrespons','NumberTitle','off');
set(gcf,'Position',[100 100 820 620]);

c1 = [0.13 0.47 0.71];   % blauw
c2 = [0.84 0.15 0.16];   % rood
c3 = [0.17 0.63 0.17];   % groen
c_ref = [0.4 0.4 0.4];   % grijs

subplot(3,1,1);
    plot(t, x_hist(1,:),  'Color', c1, 'LineWidth', 1.8); hold on;
    plot(t, xh_hist(1,:), '--', 'Color', c2, 'LineWidth', 1.4);
    yline(w_ref, 'Color', c_ref, 'LineStyle', ':', 'LineWidth', 1.2);
    ylabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Positie kar', 'FontSize', 11, 'FontWeight', 'normal');
    legend('Werkelijk', 'Observer', 'Referentie', ...
        'Location', 'best', 'FontSize', 9, 'Box', 'off');
    set(gca, 'FontSize', 10); grid on; box off;

subplot(3,1,2);
    plot(t, x_hist(3,:),  'Color', [0.75 0.22 0.17], 'LineWidth', 1.8); hold on;
    plot(t, xh_hist(3,:), '--', 'Color', [0.98 0.55 0.38], 'LineWidth', 1.4);
    yline(0, 'Color', c_ref, 'LineStyle', ':', 'LineWidth', 1.2);
    ylabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Hoek pendulum', 'FontSize', 11, 'FontWeight', 'normal');
    legend('Werkelijk', 'Observer', 'Location', 'best', 'FontSize', 9, 'Box', 'off');
    set(gca, 'FontSize', 10); grid on; box off;

subplot(3,1,3);
    plot(t, u_hist, 'Color', c3, 'LineWidth', 1.8);
    yline( F_max, 'Color', [0.7 0.1 0.1], 'LineStyle', '--', 'LineWidth', 1.0, 'Label', 'F_{max}');
    yline(-F_max, 'Color', [0.7 0.1 0.1], 'LineStyle', '--', 'LineWidth', 1.0);
    ylabel('$F$ (N)', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Tijd (s)', 'FontSize', 11);
    title('Stuurkracht', 'FontSize', 11, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;

sgtitle(sprintf('Observer validatie   $P = [%.3f,\\ %.3f,\\ %.3f,\\ %.3f]$', P_obs), ...
    'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'normal');

%% Plot 2 — schattingsfout niet-gemeten toestanden
figure('Name','Schattingsfout','NumberTitle','off');
set(gcf,'Position',[100 100 820 440]);

subplot(2,1,1);
    area(t, e_v, 'FaceColor', [0.13 0.47 0.71], 'FaceAlpha', 0.15, ...
        'EdgeColor', [0.13 0.47 0.71], 'LineWidth', 1.5);
    yline(0, 'k--', 'LineWidth', 0.8);
    rms_v = sqrt(mean(e_v.^2));
    yline( rms_v, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    yline(-rms_v, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    ylabel('$\dot{x}$ (m/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('Schattingsfout snelheid   RMS $= %.4f$ m/s', rms_v), ...
        'Interpreter', 'latex', 'FontSize', 11, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;

subplot(2,1,2);
    area(t, e_omega, 'FaceColor', [0.75 0.22 0.17], 'FaceAlpha', 0.15, ...
        'EdgeColor', [0.75 0.22 0.17], 'LineWidth', 1.5);
    yline(0, 'k--', 'LineWidth', 0.8);
    rms_om = sqrt(mean(e_omega.^2));
    yline( rms_om, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    yline(-rms_om, 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 1.0);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Tijd (s)', 'FontSize', 11);
    title(sprintf('Schattingsfout hoeksnelheid   RMS $= %.4f$ rad/s', rms_om), ...
        'Interpreter', 'latex', 'FontSize', 11, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;

sgtitle('Schattingsfout niet-gemeten toestanden $(e = x - \hat{x})$', ...
    'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'normal');

%% Plot 3 — PSO convergentie
if ~isempty(iter_log)
    figure('Name','PSO convergentie','NumberTitle','off');
    set(gcf,'Position',[100 100 700 340]);

    semilogy(iter_log(:,1), iter_log(:,2), ...
        'Color', [0.13 0.47 0.71], 'LineWidth', 1.8); hold on;
    scatter(iter_log(end,1), iter_log(end,2), 60, ...
        [0.84 0.15 0.16], 'filled');
    text(iter_log(end,1), iter_log(end,2)*1.3, ...
        sprintf('$J = %.5f$', iter_log(end,2)), ...
        'Interpreter', 'latex', 'FontSize', 10, 'HorizontalAlignment', 'right');

    xlabel('Iteratie', 'FontSize', 11);
    ylabel('Beste kost (log-schaal)', 'FontSize', 11);
    title('PSO convergentie', 'FontSize', 12, 'FontWeight', 'normal');
    set(gca, 'FontSize', 10); grid on; box off;
end
%% Opslaan naar JSON
obs.A  = A_d;
obs.B  = B_d;
obs.C  = C_d;
obs.L  = L_opt;
obs.P  = P_obs;
obs.Ts = Ts;

fid = fopen('observer_params.json', 'w');
if fid ~= -1
    fwrite(fid, jsonencode(obs));
    fclose(fid);
    fprintf('observer_params.json opgeslagen.\n');
end

fprintf('\nP_obs = [%.4f  %.4f  %.4f  %.4f];\n', P_obs);
fprintf('\n==================================================\n');
fprintf('  KLAAR\n');
fprintf('==================================================\n');

%% PSO logging hulpfunctie
function stop = pso_log(optimValues, ~)
    stop = false;
    assignin('base','iter_log', ...
        [evalin('base','iter_log'); optimValues.iteration, optimValues.bestfval]);
end

%% Kostfunctie
function J = observer_cost(p, A_d, B_d, C_d, K, Nbar, w_ref, ...
        x0, N_sim, N_mc, F_max, sigma_x, sigma_phi, delta_min)

    % Stabiliteitscheck: alle Polen binnen eenheidscirkel
    if any(abs(p) >= 1)
        J = 1e6; return;
    end

    % Polen mogen niet te dicht bij elkaar liggen (place() wordt numeriek slecht)
    pairs = nchoosek(1:4, 2);
    for i = 1:size(pairs,1)
        if abs(p(pairs(i,1)) - p(pairs(i,2))) < delta_min
            J = 1e6; return;
        end
    end

    % Observergain via pole placement
    try
        L = place(A_d', C_d', p)';
    catch
        J = 1e6; return;
    end

    % Monte Carlo: N_mc simulaties met willekeurige meetruis
    J_mc = zeros(N_mc, 1);

    for mc = 1:N_mc
        rng(mc);

        xk  = x0;
        xhk = [x0(1); 0; x0(3); 0];
        uk  = 0;
        ex  = zeros(N_sim, 1);

        for k = 1:N_sim
            % Gemeten uitgang + ruis
            yk  = C_d*xk + [sigma_x; sigma_phi] .* randn(2,1);

            % Observer update
            xhk = A_d*xhk + B_d*uk + L*(yk - C_d*xhk);

            % Regelaar met saturatie
            uk  = min(max(Nbar*w_ref - K*xhk, -F_max), F_max);

            % Positiefout t.o.v. setpoint
            ex(k) = xk(1) - w_ref;

            % Plant update (lineair model)
            xk = A_d*xk + B_d*uk;

            % Vroegtijdig afbreken bij divergentie
            if any(abs(xk) > 1e3)
                J_mc(mc) = 1e6; break;
            end
        end

        if J_mc(mc) < 1e5
            J_mc(mc) = sqrt(mean(ex.^2));  % RMSE positie
        end
    end

    J = mean(J_mc);  % gemiddelde over alle Monte Carlo runs
end