%% Luenberger Observer Design — Inverted Pendulum
%
% Vereiste: voer eerst MATLAB_Code.m en Controller.m uit zodat de volgende
%           variabelen in de workspace aanwezig zijn:
%               sys_d   — discreet toestandsruimtemodel (ss-object)
%               Ts      — bemonsteringstijd (0.05 s)
%
% Toestandsvector:  x = [x;  x_dot;  theta;  theta_dot]
% Metingen:         y = [x;  theta]   (C = [1 0 0 0; 0 0 1 0])
%
% -------------------------------------------------------------------------
% THEORIE (zie slides ES322):
%
%   De Luenberger observer schat xhat op basis van u en y:
%
%       xhat[k+1] = A_d * xhat[k] + B_d * u[k] + L * (y[k] - C * xhat[k])
%
%   De schattingsfout e = x - xhat evolueert als:
%
%       e[k+1] = (A_d - L*C) * e[k]
%
%   De observer is stabiel als alle eigenwaarden van (A_d - L*C)
%   binnen de eenheidscirkel liggen.
%
%   Berekening van L via place() met substitutie (slides ES322, slide 16):
%       A -> A^T,  B -> C^T,  K -> L^T
%   => L = place(A_d', C_d', P_obs)'
%
% =========================================================================

clc; close all;
fprintf('============================================================\n');
fprintf('  LUENBERGER OBSERVER DESIGN — discreet\n');
fprintf('  Ts = 0.05 s\n');
fprintf('============================================================\n\n');

%% Haal discrete systeemmatrices op uit workspace
A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;
D_d = sys_d.D;

fprintf('Discrete systeemmatrices:\n');
fprintf('  A_d (%dx%d), B_d (%dx%d), C_d (%dx%d)\n\n', ...
    size(A_d,1), size(A_d,2), size(B_d,1), size(B_d,2), ...
    size(C_d,1), size(C_d,2));

%% Controleer waarneembaarheid
Ob = obsv(A_d, C_d);
fprintf('Rank waarneembaarheidsmatrix: %d (moet %d zijn)\n\n', ...
    rank(Ob), size(A_d,1));

%% Open-lus polen (ter referentie)
p_ol = eig(A_d);
fprintf('Open-lus polen van A_d:\n');
for i = 1:length(p_ol)
    stabstr = '';
    if abs(p_ol(i)) > 1, stabstr = '  <-- INSTABIEL'; end
    fprintf('  p%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_ol(i)), imag(p_ol(i)), abs(p_ol(i)), stabstr);
end
fprintf('\n');

% =========================================================================
%% KEUZE VAN OBSERVER-POLEN
%
% Strategie:
%   - De gesloten-lus regelaar heeft Polen rond |z| = 0.2 - 0.6
%   - De observer moet SNELLER zijn: Polen met kleinere modulus
%   - Vuistregel: observer-Polen op factor 3-5 kleiner in modulus
%     dan de traagste CL-regelaarspool
%   - Te snel (Polen dicht bij 0): versterkt meetruis sterk (grote L)
%   - Te traag (Polen dicht bij 1): convergeert traag, weinig nut
%
% =========================================================================

% --- KIES HIER JE State Feedback OBSERVER-POLEN ---
% P_obs = [0.05, 0.04, 0.03, 0.02];         % Beste State feedback [l = % l_opt, P_cl = [0.83, 0.82, 0.81, 0.80], geen rekening houdend met marge F_max]
% P_obs = [0.1, 0.09, 0.08, 0.07];            
% P_obs = [0.15, 0.14, 0.13, 0.12];             
% P_obs = [0.2, 0.19, 0.18, 0.17];          % Beste State feedback [l = % 0.15, P_cl = [0.83, 0.82, 0.81, 0.80], geen rekening houdend met marge F_max]
% P_obs = [0.25, 0.24, 0.23, 0.22];       
% P_obs = [0.3, 0.29, 0.28, 0.27];
% P_obs = [0.35, 0.34, 0.33, 0.32];
% P_obs = [0.4,  0.35, 0.3, 0.25];
% P_obs = [0.39,  0.391, 0.392, 0.393];     %Lt State feedback
% P_obs = [0.43,  0.42, 0.41, 0.40];      
% P_obs = [0.49,  0.48, 0.47, 0.46];       
% P_obs = [0.54,  0.53, 0.52, 0.51];        % Beste State feedback [l = l_opt, P_cl = [0.80, 0.79, 0.78, 0.77], rekening houdend met marge van F_max]
% P_obs = [0.4 0.45 0.25 0.3];              % Eigen Nieuwste beste
% P_obs = [0.550, 0.551,  0.552, 0.553];   
% P_obs = [0.6,  0.59, 0.58, 0.57];
% P_obs = [0.62,  0.61, 0.60, 0.59];
% P_obs = [0.69, 0.68, 0.67, 0.66];         % Beste State feedback volgens RMS observer (ObserverOpt)
% P_obs = [0.73,  0.72, 0.71, 0.70];        % Beste State feedback [l = % 0.15, P_cl = [0.77, 0.76, 0.75, 0.74], rekening houdend met marge van F_max]
% P_obs = [0.77,  0.76, 0.75, 0.74];
% P_obs = [0.85, 0.84, 0.83, 0.82];
% P_obs = [0.90, 0.875, 0.85, 0.825];
% P_obs = [0.95, 0.925, 0.9, 0.875];

% P_obs = [0.6500 0.5055 0.3362 0.2203];        
% P_obs = [0.6500  0.5621  0.4648  0.1231];
% P_obs = [0.6500  0.5219  0.5087  0.2159];       
% P_obs = [0.6500  0.5234  0.5139  0.2141];   % SUPER DUPER BESTE State feedback bij P_cl = [0.85 0.8 0.7 0.65] rechtstereekse resultaten uit ObserverOptSFBest.m

% --- KIES HIER JE Extended State Feedback OBSERVER-POLEN ---
% P_obs = [0.05, 0.04, 0.03, 0.02];            
% P_obs = [0.07 0.06, 0.05, 0.04];            % Oude beste Extended State feedback
% P_obs = [0.1, 0.09, 0.08, 0.07];          
% P_obs = [0.15, 0.14, 0.13, 0.12];             
% P_obs = [0.2, 0.19, 0.18, 0.17];         
% P_obs = [0.25, 0.24, 0.23, 0.22];       
% P_obs = [0.3, 0.29, 0.28, 0.27];
% P_obs = [0.35 0.30 0.25 0.20];
% P_obs = [0.35, 0.34, 0.33, 0.32];
% P_obs = [0.4,  0.39, 0.38, 0.37];
% P_obs = [0.39,  0.391, 0.392, 0.393];  
% P_obs = [0.43,  0.42, 0.41, 0.40];      
% P_obs = [0.49,  0.48, 0.47, 0.46];        % Beste Extended State feedback volgens RMS observer (ObserverOpt)
% P_obs = [0.54,  0.53, 0.52, 0.51];        
% P_obs = [0.55 0.50 0.45 0.40];
% P_obs = [0.550, 0.551,  0.552, 0.553];    %Lt Extended State feedback
% P_obs = [0.50 0.53 0.67 0.70];
% P_obs = [0.6,  0.59, 0.58, 0.57];
% P_obs = [0.62,  0.61, 0.60, 0.59];
% P_obs = [0.69, 0.68, 0.67, 0.66];           
% P_obs = [0.73,  0.72, 0.71, 0.70]; 
% P_obs = [0.55 0.6 0.25 0.2];              % Nieuwste beste Extended State feedback 
% P_obs = [0.77,  0.76, 0.75, 0.74];
% P_obs = [0.85, 0.84, 0.83, 0.82];
% P_obs = [0.90, 0.875, 0.85, 0.825];
% P_obs = [0.95, 0.925, 0.9, 0.875];

P_obs = [0.6491  0.4157  0.3427  0.2356];
% P_obs = [0.55 0.6 0.25 0.2];

%% Bereken winstmatrix L
L = place(A_d', C_d', P_obs)';

fprintf('Observer-Polen (gewenst):\n');
for i = 1:length(P_obs)
    fprintf('  p_obs%d = %+.4f %+.4fi   |p| = %.4f\n', ...
        i, real(P_obs(i)), imag(P_obs(i)), abs(P_obs(i)));
end
fprintf('\n');

%% Verifieer eigenwaarden van (A_d - L*C_d)
A_obs       = A_d - L * C_d;
p_obs_check = eig(A_obs);

fprintf('Winstmatrix L =\n');
disp(L);

fprintf('Verificatie eigenwaarden van (A_d - L*C_d):\n');
all_stable = true;
for i = 1:length(p_obs_check)
    stabstr = '';
    if abs(p_obs_check(i)) >= 1
        stabstr = '  <-- INSTABIEL!';
        all_stable = false;
    end
    fprintf('  eig%d = %+.4f %+.4fi   |p| = %.4f%s\n', ...
        i, real(p_obs_check(i)), imag(p_obs_check(i)), abs(p_obs_check(i)), stabstr);
end
fprintf('\n');

if all_stable
    fprintf('  Observer is STABIEL.\n\n');
else
    fprintf('  [!] Observer NIET stabiel — pas P_obs aan.\n\n');
    return;
end
% =========================================================================
%% OPSLAAN NAAR JSON (voor Python-simulator)
% =========================================================================

fprintf('--- Observer parameters opslaan naar JSON ---\n');

obs_params.A  = A_d;
obs_params.B  = B_d;
obs_params.C  = C_d;
obs_params.L  = L;
obs_params.Ts = Ts;

output_file = 'observer_params.json';
fid = fopen(output_file, 'w');
if fid == -1
    warning('Kon %s niet schrijven.', output_file);
else
    fwrite(fid, jsonencode(obs_params));
    fclose(fid);
    fprintf('  Opgeslagen in: %s\n', output_file);
end

fprintf('\n============================================================\n');
fprintf('  KLAAR — pas P_obs aan en herrun (Ctrl+Enter)\n');
fprintf('============================================================\n');
%% VALIDATIE OP CSV-DATA (simulatie met controller)
%
% De observer krijgt enkel y = [x, phi] (measurements) en u (force),
% exact zoals hij in Python zal werken. De werkelijke toestanden uit
% pendulum_states.csv dienen als referentie om de schattingsfout te meten.
%
% De niet-gemeten toestanden x_dot en theta_dot zijn het interessantst:
% die moeten door de observer gereconstrueerd worden.
%
% Begintoestand observer: x en phi uit eerste meting, snelheden = 0.
% Dit simuleert de realistische situatie bij het opstarten.
% =========================================================================

fprintf('--- Validatie op CSV-data ---\n\n');

% Pad naar de CSV-bestanden van de controllersimulatie

 % csv_dir = fullfile(dir, 'Simulations Flament', ...
     % 'Controller 1.2 - met x controller - [-0.5, 0.0, 0.05, 0.0], Kp = -0.5, marge 0.1','v1 add noise = t');

 % csv_dir = fullfile(dir, 'Simulations Flament', ...
 %     'Controller 2.0 (ExtStFb) - [-0.25, 0.0, 0.05, 0.0] - PE[0.63, 0.62, 0.61, 0.60, 0.98] - w = 0.25');

 csv_dir = fullfile(dir);

try
    data_states       = readmatrix(fullfile(csv_dir, 'pendulum_states.csv'));
    data_inputs       = readmatrix(fullfile(csv_dir, 'pendulum_inputs.csv'));
    data_measurements = readmatrix(fullfile(csv_dir, 'pendulum_measurements.csv'));
        fprintf('  CSV geladen vanuit: %s\n\n', csv_dir);
    
    N_csv = size(data_states, 1);
    t_csv = (0:N_csv-1) * Ts;
    
    % Werkelijke toestanden: kolommen [x, v, phi, omega]
    x_csv     = data_states(:,1);
    v_csv     = data_states(:,2);
    phi_csv   = data_states(:,3);
    omega_csv = data_states(:,4);
    
    % Wat de observer ziet: metingen [x, phi] en ingang [F]
    y_csv = data_measurements';   % 2 x N  (transponeer: elke kolom = 1 tijdstap)
    u_csv = data_inputs(:,1);     % N x 1
    
    % Observer initialisatie: x en phi uit eerste meting, snelheden onbekend = 0
    xhat_k_csv = [y_csv(1,1); 0; y_csv(2,1); 0];
    xhat_csv   = zeros(4, N_csv);
    
    for k = 1:N_csv
        xhat_csv(:, k) = xhat_k_csv;
        y_k   = y_csv(:, k);
        yhat_k = C_d * xhat_k_csv;
        u_k   = u_csv(k);
        % Observer update
        xhat_k_csv = A_d * xhat_k_csv + B_d * u_k + L * (y_k - yhat_k);
    end
    
    % RMS-fouten op de NIET-gemeten toestanden
    e_v     = v_csv'     - xhat_csv(2,:);
    e_omega = omega_csv' - xhat_csv(4,:);
    
    % RMS-fouten op de gemeten toestanden
    e_x     = x_csv'     - xhat_csv(1,:);
    e_phi = phi_csv' - xhat_csv(3,:);
    
    fprintf('  RMS fout x_dot:     %.4f m/s\n',   sqrt(mean(e_v.^2)));
    fprintf('  RMS fout theta_dot: %.4f rad/s\n\n', sqrt(mean(e_omega.^2)));
    
    fprintf('  RMS fout x:     %.4f m/s\n',   sqrt(mean(e_x.^2)));
    fprintf('  RMS fout theta: %.4f rad/s\n\n', sqrt(mean(e_phi.^2)));
    
    %% Plot: alle 4 toestanden — werkelijk vs observer
    figure('Name','Observer validatie — alle toestanden','NumberTitle','off');
    
    subplot(2,2,1);
        plot(t_csv, x_csv,         'DisplayName', 'Werkelijk'); hold on;
        plot(t_csv, y_csv(1,:),    'DisplayName', 'Gemeten');  
        plot(t_csv, xhat_csv(1,:), '--', 'DisplayName', 'Observer');
        ylabel('$x$ (m)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
        title('Positie $x$ [Gemeten]', 'Interpreter', 'latex');
        legend('Location','best', 'Interpreter', 'latex'); grid on;
    
    subplot(2,2,2);
        plot(t_csv, v_csv,         'DisplayName', 'Werkelijk'); hold on;
        plot(t_csv, xhat_csv(2,:), '--', 'DisplayName', 'Observer');
        ylabel('$\dot{x}$ (m/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
        title('Snelheid $\dot{x}$ [Niet gemeten]', 'Interpreter', 'latex');
        legend('Location','best', 'Interpreter', 'latex'); grid on;
    
    subplot(2,2,3);
        plot(t_csv, phi_csv,       'DisplayName', 'Werkelijk'); hold on;
        plot(t_csv, y_csv(2,:),    'DisplayName', 'Gemeten');    
        plot(t_csv, xhat_csv(3,:), '--', 'DisplayName', 'Observer');
        ylabel('$\theta$ (rad)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
        title('Hoek $\theta$ [Gemeten]', 'Interpreter', 'latex');
        legend('Location','best', 'Interpreter', 'latex'); grid on;
    
    subplot(2,2,4);
        plot(t_csv, omega_csv,     'DisplayName', 'Werkelijk'); hold on;
        plot(t_csv, xhat_csv(4,:), '--', 'DisplayName', 'Observer');
        ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
        title('Hoeksnelheid $\dot{\theta}$ [Niet gemeten]', 'Interpreter', 'latex');
        legend('Location','best', 'Interpreter', 'latex'); grid on;
    
    sgtitle(sprintf('Luenberger Observer Validatie: Polen [$%.3f, %.3f, %.3f, %.3f$]', P_obs), 'Interpreter', 'latex');
    %% Plot: schattingsfout op niet-gemeten toestanden
    figure('Name','Schattingsfout niet-gemeten toestanden','NumberTitle','off');
    
    subplot(2,1,1);
        plot(t_csv, e_v, 'LineWidth', 1.5);
        yline(0, 'k--');
        ylabel('Fout $\dot{x}$ (m/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
        title('Schattingsfout snelheid $\dot{x}$', 'Interpreter', 'latex'); grid on;
    
    subplot(2,1,2);
        plot(t_csv, e_omega, 'LineWidth', 1.5);
        yline(0, 'k--');
        ylabel('Fout $\dot{\theta}$ (rad/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
        title('Schattingsfout hoeksnelheid $\dot{\theta}$', 'Interpreter', 'latex'); grid on;
    
    % subplot(2,1,1);
    %     plot(t_csv, e_x, 'LineWidth', 1.5);
    %     yline(0, 'k--');
    %     ylabel('Fout $\dot{x}$ (m/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
    %     title('Schattingsfout $x$', 'Interpreter', 'latex'); grid on;
    % 
    % subplot(2,1,2);
    %     plot(t_csv, e_phi, 'LineWidth', 1.5);
    %     yline(0, 'k--');
    %     ylabel('Fout $\dot{\theta}$ (rad/s)', 'Interpreter', 'latex'); xlabel('Tijd (s)');
    %     title('Schattingsfout  $\theta$', 'Interpreter', 'latex'); grid on;
    % 
catch
    warning("First run PENDULUM.PY to get validation on simulated data")
end